-keepclassmembers class com.abousabra.gate.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
