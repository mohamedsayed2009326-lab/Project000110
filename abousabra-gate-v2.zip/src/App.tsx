import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Download,
  MapPin,
  Mic,
  MicOff,
  Moon,
  Pause,
  Play,
  Send,
  Settings,
  Sun,
  Trash2,
} from 'lucide-react';
import {
  formatPlateDisplay,
  normalizePlateText,
  parseSinglePlateInput,
  splitPlateParts,
  StreamPlateParser,
  validatePlate,
} from './core/plateParser';
import {
  findMatchingZone,
  GeoLookupQueue,
  parseZonesText,
} from './core/geoZones';
import {
  exportRecordsToXlsx,
  parsePastedPlatesText,
  streamImportWatchlistFile,
} from './core/xlsxCodec';
import {
  clearWatchlistDB,
  countWatchlistEntries,
  loadGeoCache,
  loadRecords,
  loadSettings,
  loadZones,
  lookupWatchlistMany,
  lookupWatchlistPlate,
  putWatchlistBatch,
  saveGeoCache,
  saveRecords,
  saveSettings,
  saveZones,
} from './core/storage';
import {
  GeminiLiveClient,
  type LiveSessionState,
  type SignalQuality,
} from './core/geminiLive';
import {
  exportViaSaveDownloads,
  exportViaShare,
  fetchAndroidSharedImportFile,
  triggerWantedFeedback,
} from './core/androidBridge';
import type {
  AppSettings,
  CheckMode,
  GeoZone,
  PendingColumnSelection,
  PlateRecord,
  WatchlistEntry,
} from './core/types';
import { SplashOverlay } from './components/SplashOverlay';
import { RecordsTable } from './components/RecordsTable';
import { SettingsModal } from './components/SettingsModal';
import { WantedAlertModal } from './components/WantedAlertModal';
import { ExportModal } from './components/ExportModal';
import { ColumnPickerModal } from './components/ColumnPickerModal';
import { RetroMatchModal } from './components/RetroMatchModal';

type TabKey = 'all' | 'check' | 'manual';

interface GpsFix {
  lat: number;
  lng: number;
  timestamp: number;
}

const GPS_FRESH_MS = 2 * 60 * 1000;

export default function App() {
  const [showSplash, setShowSplash] = useState(() => {
    if (typeof window !== 'undefined') {
      return !new URLSearchParams(window.location.search).has('autostart');
    }
    return true;
  });

  const [activeTab, setActiveTab] = useState<TabKey>('check');
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [records, setRecords] = useState<PlateRecord[]>(() => loadRecords());
  const [zones, setZones] = useState<GeoZone[]>(() => loadZones());
  const [watchlistCount, setWatchlistCount] = useState<number>(0);

  // Voice & audio state
  const [liveState, setLiveState] = useState<LiveSessionState>('idle');
  const [liveError, setLiveError] = useState<string>('');
  const [interimText, setInterimText] = useState<string>('');
  const [pendingBuffer, setPendingBuffer] = useState<{ letters: string; digits: string }>({
    letters: '',
    digits: '',
  });
  const [audioPercent, setAudioPercent] = useState<number>(0);
  const [signalQuality, setSignalQuality] = useState<SignalQuality>('ضعيف');
  const [pausedForWanted, setPausedForWanted] = useState<boolean>(false);

  // Manual check input
  const [manualInput, setManualInput] = useState<string>('');
  const [manualFeedback, setManualFeedback] = useState<string>('');

  // GPS state
  const [gpsEnabled, setGpsEnabled] = useState<boolean>(false);
  const [gpsFix, setGpsFix] = useState<GpsFix | null>(null);
  const [gpsError, setGpsError] = useState<string>('');
  const watchIdRef = useRef<number | null>(null);

  // Modals & notifications
  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);
  const [exportOpen, setExportOpen] = useState<boolean>(false);
  const [exportBusy, setExportBusy] = useState<boolean>(false);
  const [exportStatus, setExportStatus] = useState<string>('');
  const [wantedAlert, setWantedAlert] = useState<{ plate: string; data: WatchlistEntry } | null>(null);
  const [retroMatches, setRetroMatches] = useState<{ matches: PlateRecord[]; title?: string } | null>(null);
  const [pendingColPicker, setPendingColPicker] = useState<PendingColumnSelection | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState<boolean>(false);

  const [importProgress, setImportProgress] = useState({
    active: false,
    rowsScanned: 0,
    importedCount: 0,
    message: '',
  });

  // Undo delete bar (6s)
  const [undoItem, setUndoItem] = useState<{ record: PlateRecord; index: number } | null>(null);
  const undoTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Mutable refs for async callbacks
  const recordsRef = useRef(records);
  recordsRef.current = records;
  const zonesRef = useRef(zones);
  zonesRef.current = zones;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const gpsFixRef = useRef(gpsFix);
  gpsFixRef.current = gpsFix;

  const geoQueueRef = useRef<GeoLookupQueue | null>(null);
  if (!geoQueueRef.current) {
    geoQueueRef.current = new GeoLookupQueue(loadGeoCache(), saveGeoCache);
  }

  const liveClientRef = useRef<GeminiLiveClient | null>(null);
  const parserRef = useRef<StreamPlateParser | null>(null);

  // Splash fade
  useEffect(() => {
    if (!showSplash) return;
    const t = setTimeout(() => setShowSplash(false), 650);
    return () => clearTimeout(t);
  }, [showSplash]);

  // Apply theme class to <html>
  useEffect(() => {
    document.documentElement.classList.toggle('dark', settings.theme === 'dark');
    saveSettings(settings);
  }, [settings]);

  // Persist records & zones
  useEffect(() => {
    saveRecords(records);
  }, [records]);

  useEffect(() => {
    saveZones(zones);
  }, [zones]);

  // Load initial watchlist count
  useEffect(() => {
    void countWatchlistEntries().then(setWatchlistCount);
  }, []);

  // Resolve location name for a record (zone first, then cache / Nominatim)
  const resolveRecordLocation = useCallback(
    async (recordId: string, lat: number, lng: number) => {
      const zone = findMatchingZone(lat, lng, zonesRef.current);
      if (zone) {
        setRecords((prev) =>
          prev.map((r) =>
            r.id === recordId ? { ...r, locationName: zone.name, locationSource: 'zone' } : r
          )
        );
        return;
      }

      const cached = geoQueueRef.current?.getCached(lat, lng);
      if (cached) {
        setRecords((prev) =>
          prev.map((r) =>
            r.id === recordId ? { ...r, locationName: cached.name, locationSource: cached.source } : r
          )
        );
        return;
      }

      const res = await geoQueueRef.current?.resolve(lat, lng);
      if (res) {
        setRecords((prev) =>
          prev.map((r) =>
            r.id === recordId ? { ...r, locationName: res.name, locationSource: res.source } : r
          )
        );
      } else {
        setRecords((prev) =>
          prev.map((r) =>
            r.id === recordId && !r.locationName ? { ...r, locationSource: 'pending' } : r
          )
        );
      }
    },
    []
  );

  // Retry pending neighborhood lookups every 20 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const pending = recordsRef.current.filter(
        (r) =>
          r.lat !== undefined &&
          r.lng !== undefined &&
          (!r.locationName || r.locationSource === 'pending')
      );
      if (pending.length === 0) return;
      const target = pending[0];
      void resolveRecordLocation(target.id, target.lat!, target.lng!);
    }, 20000);
    return () => clearInterval(interval);
  }, [resolveRecordLocation]);

  // GPS watcher
  const startGps = useCallback(() => {
    if (!navigator.geolocation) {
      setGpsError('جهازك لا يدعم تحديد الموقع GPS');
      return;
    }
    if (watchIdRef.current !== null) return;
    setGpsError('');
    setGpsEnabled(true);
    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        setGpsFix({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          timestamp: Date.now(),
        });
        setGpsError('');
      },
      (err) => {
        if (err.code === 1) {
          setGpsError('تم رفض صلاحية الموقع');
          setGpsEnabled(false);
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }
        } else {
          setGpsError('جاري البحث عن إشارة GPS...');
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 15000,
        timeout: 15000,
      }
    );
  }, []);

  const stopGps = useCallback(() => {
    if (watchIdRef.current !== null && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setGpsEnabled(false);
  }, []);

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  // Core plate commit handler (used by both Voice & Manual)
  const addCommittedPlate = useCallback(
    async (payload: {
      plate: string;
      letters: string;
      digits: string;
      status: 'valid' | 'invalid' | 'wanted';
      vehicleType: string;
      source: 'voice' | 'manual';
      emittedAt: number;
    }) => {
      const id = `rec_${payload.emittedAt}_${Math.random().toString(36).slice(2, 7)}`;
      const fix = gpsFixRef.current;
      const hasFreshFix = fix && Date.now() - fix.timestamp <= GPS_FRESH_MS;

      let initialZoneName: string | undefined;
      let initialLocSource: PlateRecord['locationSource'] = 'none';
      if (hasFreshFix) {
        const z = findMatchingZone(fix.lat, fix.lng, zonesRef.current);
        if (z) {
          initialZoneName = z.name;
          initialLocSource = 'zone';
        } else {
          const cached = geoQueueRef.current?.getCached(fix.lat, fix.lng);
          if (cached) {
            initialZoneName = cached.name;
            initialLocSource = cached.source;
          } else {
            initialLocSource = 'pending';
          }
        }
      }

      const matched = await lookupWatchlistPlate(payload.plate);
      const finalStatus = matched ? 'wanted' : payload.status;

      const newRec: PlateRecord = {
        id,
        plate: payload.plate,
        letters: payload.letters,
        digits: payload.digits,
        vehicleType: payload.vehicleType,
        status: finalStatus,
        wantedData: matched ?? undefined,
        timestamp: payload.emittedAt,
        lat: hasFreshFix ? fix.lat : undefined,
        lng: hasFreshFix ? fix.lng : undefined,
        geoCapturedAt: hasFreshFix ? fix.timestamp : undefined,
        locationName: initialZoneName,
        locationSource: initialLocSource,
        mode: settingsRef.current.mode,
        source: payload.source,
      };

      setRecords((prev) => [newRec, ...prev]);

      if (hasFreshFix && initialLocSource === 'pending') {
        void resolveRecordLocation(id, fix.lat, fix.lng);
      }

      if (matched) {
        if (payload.source === 'voice' && liveClientRef.current) {
          liveClientRef.current.pause();
          setPausedForWanted(true);
        }
        triggerWantedFeedback(formatPlateDisplay(payload.plate));
        setWantedAlert({ plate: payload.plate, data: matched });
      }
    },
    [resolveRecordLocation]
  );

  // Initialize stream parser once
  useEffect(() => {
    parserRef.current = new StreamPlateParser({
      onPlateEmitted: (ev) => {
        void addCommittedPlate({
          ...ev,
          source: 'voice',
        });
      },
      onVehicleTypeAttached: (vehicleType) => {
        setRecords((prev) => {
          const idx = prev.findIndex((r) => r.source === 'voice' && !r.vehicleType);
          if (idx === -1) return prev;
          const next = [...prev];
          next[idx] = { ...next[idx], vehicleType };
          return next;
        });
      },
      onStateChange: (pending) => {
        setPendingBuffer(pending);
      },
    });
    return () => {
      parserRef.current?.reset();
    };
  }, [addCommittedPlate]);

  // Voice session controls
  const startVoiceSession = useCallback(async () => {
    setLiveError('');
    setPausedForWanted(false);
    startGps();

    if (!liveClientRef.current) {
      liveClientRef.current = new GeminiLiveClient({
        onStateChange: (st) => setLiveState(st),
        onInterimText: (txt) => setInterimText(txt),
        onCommittedText: (txt) => parserRef.current?.feedText(txt),
        onTurnComplete: () => parserRef.current?.flushOnTurnComplete(),
        onAudioLevel: (pct, sig) => {
          setAudioPercent(pct);
          setSignalQuality(sig);
        },
        onError: (msg) => setLiveError(msg),
      });
    }

    await liveClientRef.current.start();
  }, [startGps]);

  const stopVoiceSession = useCallback(() => {
    parserRef.current?.flushOnTurnComplete();
    liveClientRef.current?.stop();
    setPausedForWanted(false);
    setInterimText('');
  }, []);

  const resumeVoiceSession = useCallback(() => {
    setPausedForWanted(false);
    liveClientRef.current?.resume();
  }, []);

  useEffect(() => {
    return () => {
      liveClientRef.current?.stop();
    };
  }, []);

  // Retroactive scan across existing records after watchlist import/paste
  const runRetroactiveScan = useCallback(async (previousWantedIds: Set<string>) => {
    const allPlates = recordsRef.current.map((r) => r.plate);
    const matchMap = await lookupWatchlistMany(allPlates);

    const updatedRecords = recordsRef.current.map((rec) => {
      const m = matchMap.get(rec.plate);
      if (m) {
        return {
          ...rec,
          status: 'wanted' as const,
          wantedData: m,
          isNewMatch: !previousWantedIds.has(rec.id),
        };
      }
      const { status } = validatePlate(rec.letters, rec.digits);
      return {
        ...rec,
        status,
        wantedData: undefined,
        isNewMatch: false,
      };
    });

    setRecords(updatedRecords);
    const matchedList = updatedRecords.filter((r) => r.status === 'wanted');
    if (matchedList.length > 0) {
      setRetroMatches({ matches: matchedList });
    }
  }, []);

  // Upload XLSX/CSV watchlist (replaces old store completely)
  const handleImportWatchlistBlob = useCallback(
    async (file: Blob, fileName: string, forcedCol?: number) => {
      setImportProgress({ active: true, rowsScanned: 0, importedCount: 0, message: '' });
      const prevWantedIds = new Set(
        recordsRef.current.filter((r) => r.status === 'wanted').map((r) => r.id)
      );

      try {
        await clearWatchlistDB();
        let totalImported = 0;

        const res = await streamImportWatchlistFile(file, fileName, {
          forcedPlateCol: forcedCol,
          onBatch: async (batch) => {
            await putWatchlistBatch(batch);
            totalImported += batch.length;
          },
          onProgress: (rowsScanned, importedCount) => {
            setImportProgress({
              active: true,
              rowsScanned,
              importedCount,
              message: '',
            });
          },
        });

        if (res.needsColumnSelection) {
          setImportProgress({ active: false, rowsScanned: 0, importedCount: 0, message: '' });
          setPendingColPicker({
            fileName,
            headers: res.needsColumnSelection.headers,
            samples: res.needsColumnSelection.samples,
            onSelectColumn: async (colIdx) => {
              setPendingColPicker(null);
              await handleImportWatchlistBlob(file, fileName, colIdx);
            },
          });
          return;
        }

        const count = await countWatchlistEntries();
        setWatchlistCount(count);
        setSettings((prev) => ({
          ...prev,
          watchlistMeta: {
            fileName,
            count,
            updatedAt: Date.now(),
          },
        }));
        setImportProgress({
          active: false,
          rowsScanned: res.totalRowsScanned,
          importedCount: totalImported,
          message: `تم تحديث ملف المطابقة بنجاح (${count.toLocaleString('ar-EG')} لوحة من ${res.totalRowsScanned.toLocaleString('ar-EG')} صف).`,
        });

        await runRetroactiveScan(prevWantedIds);
      } catch (err) {
        setImportProgress({
          active: false,
          rowsScanned: 0,
          importedCount: 0,
          message: err instanceof Error ? err.message : 'حدث خطأ أثناء قراءة الملف',
        });
      }
    },
    [runRetroactiveScan]
  );

  // Android Intent shared file ingestion
  useEffect(() => {
    const checkShared = async () => {
      const shared = await fetchAndroidSharedImportFile();
      if (shared) {
        setSettingsOpen(true);
        await handleImportWatchlistBlob(shared.blob, shared.fileName);
      }
    };
    void checkShared();
    window.onSharedFileAvailable = () => {
      void checkShared();
    };
    return () => {
      window.onSharedFileAvailable = undefined;
    };
  }, [handleImportWatchlistBlob]);

  const handlePasteWatchlist = async (text: string) => {
    const entries = parsePastedPlatesText(text);
    if (entries.length === 0) {
      setImportProgress({
        active: false,
        rowsScanned: 0,
        importedCount: 0,
        message: 'لم يتم العثور على لوحات صالحة في النص الملصوق.',
      });
      return;
    }
    const prevWantedIds = new Set(
      recordsRef.current.filter((r) => r.status === 'wanted').map((r) => r.id)
    );
    await putWatchlistBatch(entries);
    const count = await countWatchlistEntries();
    setWatchlistCount(count);
    setImportProgress({
      active: false,
      rowsScanned: entries.length,
      importedCount: entries.length,
      message: `تمت إضافة ${entries.length} لوحة لملف المطابقة.`,
    });
    await runRetroactiveScan(prevWantedIds);
  };

  // Zones update & re-apply to all existing records
  const handleSaveZonesText = (text: string) => {
    const res = parseZonesText(text, zones);
    setZones(res.zones);
    setRecords((prev) =>
      prev.map((rec) => {
        if (rec.lat === undefined || rec.lng === undefined) return rec;
        const z = findMatchingZone(rec.lat, rec.lng, res.zones);
        if (z) {
          return { ...rec, locationName: z.name, locationSource: 'zone' };
        }
        return rec;
      })
    );
    return { added: res.added, updated: res.updated, errors: res.errors };
  };

  const handleClearZones = () => {
    setZones([]);
    setRecords((prev) =>
      prev.map((rec) => {
        if (rec.locationSource === 'zone') {
          return { ...rec, locationName: undefined, locationSource: 'pending' };
        }
        return rec;
      })
    );
  };

  // Inline plate edit
  const handleEditPlate = async (id: string, rawInput: string) => {
    const normalized = normalizePlateText(rawInput);
    if (!normalized) return;
    const { letters, digits } = splitPlateParts(normalized);
    const { status } = validatePlate(letters, digits);
    const matched = await lookupWatchlistPlate(normalized);

    setRecords((prev) =>
      prev.map((rec) =>
        rec.id === id
          ? {
              ...rec,
              plate: normalized,
              letters,
              digits,
              status: matched ? 'wanted' : status,
              wantedData: matched ?? undefined,
            }
          : rec
      )
    );

    if (matched) {
      triggerWantedFeedback(formatPlateDisplay(normalized));
      setWantedAlert({ plate: normalized, data: matched });
    }
  };

  // Delete + 6-second Undo bar
  const handleDeleteRecord = (id: string) => {
    const idx = records.findIndex((r) => r.id === id);
    if (idx === -1) return;
    const removed = records[idx];
    setRecords((prev) => prev.filter((r) => r.id !== id));

    if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
    setUndoItem({ record: removed, index: idx });
    undoTimerRef.current = setTimeout(() => {
      setUndoItem(null);
    }, 6000);
  };

  const handleUndoDelete = () => {
    if (!undoItem) return;
    if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
    const { record, index } = undoItem;
    setRecords((prev) => {
      const next = [...prev];
      next.splice(Math.min(index, next.length), 0, record);
      return next;
    });
    setUndoItem(null);
  };

  // Manual check submission
  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const raw = manualInput.trim();
    if (!raw) return;

    const parsed = parseSinglePlateInput(raw);
    if (parsed.length === 0) {
      setManualFeedback('اكتب حروف وأرقام اللوحة بشكل صحيح (مثال: رحم3249 أو ر ح م 324)');
      return;
    }

    setManualInput('');
    setManualFeedback('');
    for (const item of parsed) {
      await addCommittedPlate({
        ...item,
        source: 'manual',
      });
    }
  };

  // Export flow: resolve missing neighborhoods first, then write RTL XLSX
  const prepareExportBytes = async (): Promise<{ bytes: Uint8Array; fileName: string }> => {
    setExportBusy(true);
    setExportStatus('جاري تجهيز أسماء الأحياء والمناطق...');
    const current = [...recordsRef.current];
    const missing = current.filter(
      (r) =>
        r.lat !== undefined &&
        r.lng !== undefined &&
        (!r.locationName || r.locationSource === 'pending')
    );

    for (let i = 0; i < Math.min(missing.length, 15); i++) {
      const rec = missing[i];
      if (rec.lat !== undefined && rec.lng !== undefined && geoQueueRef.current) {
        const zone = findMatchingZone(rec.lat, rec.lng, zonesRef.current);
        if (zone) {
          rec.locationName = zone.name;
          rec.locationSource = 'zone';
        } else {
          const resolved = await Promise.race([
            geoQueueRef.current.resolve(rec.lat, rec.lng),
            new Promise<null>((r) => setTimeout(() => r(null), 2000)),
          ]);
          if (resolved) {
            rec.locationName = resolved.name;
            rec.locationSource = resolved.source;
          }
        }
      }
    }

    setRecords(current);
    setExportStatus('جاري إنشاء ملف الإكسل...');
    const bytes = exportRecordsToXlsx(current);
    const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
    const fileName = `سجل_بوابة_ابو_صبره_${stamp}.xlsx`;
    return { bytes, fileName };
  };

  const handleExportShare = async () => {
    try {
      const { bytes, fileName } = await prepareExportBytes();
      await exportViaShare(bytes, fileName);
      setExportOpen(false);
    } catch (err) {
      setExportStatus(err instanceof Error ? err.message : 'فشلت المشاركة');
    } finally {
      setExportBusy(false);
      setExportStatus('');
    }
  };

  const handleExportDownload = async () => {
    try {
      const { bytes, fileName } = await prepareExportBytes();
      await exportViaSaveDownloads(bytes, fileName);
      setExportOpen(false);
    } catch (err) {
      setExportStatus(err instanceof Error ? err.message : 'فشل التنزيل');
    } finally {
      setExportBusy(false);
      setExportStatus('');
    }
  };

  const stats = useMemo(() => {
    let valid = 0;
    let wanted = 0;
    let invalid = 0;
    for (const r of records) {
      if (r.status === 'wanted') wanted++;
      else if (r.status === 'invalid') invalid++;
      else valid++;
    }
    return { total: records.length, valid, wanted, invalid };
  }, [records]);

  const wantedRecords = useMemo(
    () => records.filter((r) => r.status === 'wanted'),
    [records]
  );

  const setMode = (mode: CheckMode) => {
    setSettings((prev) => ({ ...prev, mode }));
  };

  const toggleTheme = () => {
    setSettings((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  };

  return (
    <div className="min-h-screen bg-[var(--bg-canvas)] text-[var(--text-primary)] pb-20">
      <SplashOverlay visible={showSplash} />

      {/* Top Header (compact <= 52px) */}
      <header className="sticky top-0 z-30 border-b border-[var(--border-hairline)] bg-[var(--bg-canvas)]/90 backdrop-blur-md">
        <div className="mx-auto flex h-13 max-w-5xl items-center justify-between px-3 sm:px-5">
          <div className="flex items-center gap-2 min-w-0">
            <span className="truncate text-base sm:text-lg font-extrabold tracking-tight text-[#0d8a5f] dark:text-[#5eddaa]">
              بوابة ابو صبره
            </span>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() =>
                setRetroMatches({
                  matches: wantedRecords,
                  title: `اللوحات المطلوبة في السجل (${wantedRecords.length})`,
                })
              }
              aria-label="عرض اللوحات المطلوبة"
              className="relative inline-flex h-11 min-w-[44px] items-center justify-center gap-1 rounded-xl px-2 text-amber-500 hover:bg-[var(--bg-elevated)] transition"
            >
              <AlertTriangle className="h-5 w-5" aria-hidden="true" />
              {wantedRecords.length > 0 && (
                <span className="text-xs font-extrabold tabular-nums">
                  {wantedRecords.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              aria-label="الإعدادات"
              className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] transition"
            >
              <Settings className="h-5 w-5" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={toggleTheme}
              aria-label={settings.theme === 'dark' ? 'التبديل للثيم الفاتح' : 'التبديل للثيم الداكن'}
              className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] transition"
            >
              {settings.theme === 'dark' ? (
                <Sun className="h-5 w-5 text-[#f0b942]" aria-hidden="true" />
              ) : (
                <Moon className="h-5 w-5" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-5xl px-3 py-4 sm:px-5 space-y-4">
        {/* TAB: الفحص الصوتي */}
        {activeTab === 'check' && (
          <div className="space-y-4">
            {/* Mode Switch */}
            <div className="grid grid-cols-2 gap-1.5 rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] p-1.5">
              <button
                type="button"
                onClick={() => setMode('abousabra')}
                className={`min-h-[44px] rounded-xl px-3 py-2 text-xs sm:text-sm font-extrabold transition ${
                  settings.mode === 'abousabra'
                    ? 'bg-[#f0b942] text-[#06100c]'
                    : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                }`}
              >
                تشييك ابو صبره
              </button>
              <button
                type="button"
                onClick={() => setMode('external')}
                className={`min-h-[44px] rounded-xl px-3 py-2 text-xs sm:text-sm font-extrabold transition ${
                  settings.mode === 'external'
                    ? 'bg-[#f0b942] text-[#06100c]'
                    : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                }`}
              >
                خارجي
              </button>
            </div>

            {/* Yellow Resume Card when paused due to Wanted plate */}
            {pausedForWanted && (
              <div className="rounded-2xl border-2 border-amber-400 bg-amber-500/15 p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <h2 className="text-sm font-extrabold text-amber-600 dark:text-amber-300">
                    تم إيقاف الفحص الصوتي مؤقتاً لظهور لوحة مطلوبة
                  </h2>
                  <p className="text-xs text-[var(--text-muted)] mt-0.5">
                    بعد مراجعة بيانات المطلوب اضغط استئناف الفحص الصوتي للمتابعة.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={resumeVoiceSession}
                  className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-[#f0b942] px-5 py-2.5 text-sm font-extrabold text-[#06100c] shrink-0"
                >
                  <Play className="h-4 w-4" aria-hidden="true" />
                  <span>استئناف الفحص الصوتي</span>
                </button>
              </div>
            )}

            {/* Voice Session Card */}
            <section className="rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] p-4 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-base font-extrabold text-[var(--text-primary)]">
                    {liveState === 'listening'
                      ? 'يستمع الآن'
                      : liveState === 'connecting'
                      ? 'جاري الاتصال بـ Gemini Live...'
                      : liveState === 'reconnecting'
                      ? 'إعادة اتصال تلقائية...'
                      : liveState === 'paused'
                      ? 'متوقف مؤقتاً'
                      : liveState === 'error'
                      ? 'تعذر بدء الجلسة'
                      : 'جاهز للفحص الصوتي'}
                  </div>
                  <div className="mt-0.5 text-xs text-[var(--text-muted)] tabular-nums">
                    ملف المطابقة: {watchlistCount.toLocaleString('en-US')} لوحة · السجل: {stats.total}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {liveState === 'idle' || liveState === 'error' ? (
                    <button
                      type="button"
                      onClick={() => void startVoiceSession()}
                      className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-[#f0b942] px-5 py-2.5 text-sm font-extrabold text-[#06100c] hover:brightness-105 transition"
                    >
                      <Mic className="h-4 w-4" aria-hidden="true" />
                      <span>بدء الفحص</span>
                    </button>
                  ) : (
                    <>
                      {liveState === 'paused' ? (
                        <button
                          type="button"
                          onClick={resumeVoiceSession}
                          className="inline-flex min-h-[46px] items-center justify-center gap-1.5 rounded-xl bg-[#f0b942] px-4 py-2.5 text-sm font-extrabold text-[#06100c]"
                        >
                          <Play className="h-4 w-4" aria-hidden="true" />
                          <span>استئناف</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            liveClientRef.current?.pause();
                          }}
                          aria-label="إيقاف مؤقت"
                          className="inline-flex min-h-[46px] items-center justify-center gap-1.5 rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] px-3.5 py-2.5 text-xs font-bold text-[var(--text-primary)]"
                        >
                          <Pause className="h-4 w-4" aria-hidden="true" />
                          <span>إيقاف مؤقت</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={stopVoiceSession}
                        className="inline-flex min-h-[46px] items-center justify-center gap-1.5 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-red-500 transition"
                      >
                        <MicOff className="h-4 w-4" aria-hidden="true" />
                        <span>إيقاف</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

              {liveError && (
                <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2.5 text-xs font-semibold text-red-600 dark:text-red-300">
                  {liveError}
                </div>
              )}

              {/* Interim transcription & pending plate buffer */}
              <div className="rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] px-3 py-2.5 text-xs min-h-[44px] flex flex-wrap items-center justify-between gap-2">
                <div className="text-[var(--text-primary)] break-words">
                  <span className="text-[var(--text-muted)]">النص المؤقت: </span>
                  <span className="font-semibold">
                    {interimText || (liveState === 'listening' ? 'تحدّث باللوحة الآن...' : '—')}
                  </span>
                </div>
                {(pendingBuffer.letters || pendingBuffer.digits) && (
                  <span className="font-plate font-extrabold text-[#0d8a5f] dark:text-[#5eddaa]">
                    جاري التجميع: {pendingBuffer.letters.split('').join(' ')} {pendingBuffer.digits}
                  </span>
                )}
              </div>

              {/* Controls row: GPS toggle + Audio level & signal */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => (gpsEnabled ? stopGps() : startGps())}
                  className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-bold transition ${
                    gpsEnabled
                      ? 'border-[#5eddaa]/50 bg-[#5eddaa]/10 text-[#0d8a5f] dark:text-[#5eddaa]'
                      : 'border-[var(--border-hairline)] bg-[var(--bg-elevated)] text-[var(--text-muted)]'
                  }`}
                >
                  <span>
                    📍 الموقع:{' '}
                    {gpsEnabled
                      ? gpsFix
                        ? `${gpsFix.lat.toFixed(4)}, ${gpsFix.lng.toFixed(4)}`
                        : 'جاري التحديد...'
                      : 'متوقف'}
                  </span>
                </button>

                <div className="flex items-center gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-[var(--text-muted)]">الصوت:</span>
                    <div className="h-2 w-20 overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                      <div
                        className="h-full bg-[#5eddaa] transition-all duration-100"
                        style={{ width: `${audioPercent}%` }}
                      />
                    </div>
                    <span className="w-8 font-mono font-bold tabular-nums text-[var(--text-primary)]">
                      {audioPercent}%
                    </span>
                  </div>
                  <span className="text-[var(--text-muted)]">
                    الإشارة: <strong className="text-[var(--text-primary)]">{signalQuality}</strong>
                  </span>
                </div>
              </div>

              {gpsError && (
                <p className="text-xs text-amber-600 dark:text-amber-400">{gpsError}</p>
              )}
            </section>

            {/* Records Table */}
            <RecordsTable
              records={records}
              onDelete={handleDeleteRecord}
              onEditPlate={(id, val) => void handleEditPlate(id, val)}
            />
          </div>
        )}

        {/* TAB: فحص يدوي */}
        {activeTab === 'manual' && (
          <div className="space-y-4">
            <section className="rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-base font-extrabold text-[var(--text-primary)]">
                  فحص لوحة يدوياً
                </h2>
                <button
                  type="button"
                  onClick={() => (gpsEnabled ? stopGps() : startGps())}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-bold text-[var(--text-primary)]"
                >
                  <MapPin className="h-3.5 w-3.5 text-[#5eddaa]" aria-hidden="true" />
                  <span>{gpsEnabled ? 'GPS نشط' : 'تشغيل GPS'}</span>
                </button>
              </div>

              <form onSubmit={(e) => void handleManualSubmit(e)} className="flex gap-2">
                <input
                  type="text"
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  enterKeyHint="send"
                  aria-label="إدخال رقم اللوحة"
                  placeholder="مثال: رحم3249 أو ر ح م 324 ملاكي"
                  className="min-h-[48px] flex-1 rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] px-3.5 text-base font-bold text-[var(--text-primary)] outline-none focus:border-[#5eddaa]"
                />
                <button
                  type="submit"
                  aria-label="إضافة اللوحة"
                  className="inline-flex min-h-[48px] min-w-[52px] items-center justify-center rounded-xl bg-[#f0b942] px-4 text-[#06100c] font-extrabold hover:brightness-105 transition"
                >
                  <Send className="h-5 w-5" aria-hidden="true" />
                </button>
              </form>

              {manualFeedback && (
                <p className="text-xs font-semibold text-red-500">{manualFeedback}</p>
              )}
            </section>

            <div className="space-y-2">
              <h3 className="text-sm font-bold text-[var(--text-muted)]">آخر 5 لوحات</h3>
              <RecordsTable
                records={records.slice(0, 5)}
                emptyMessage="اكتب أول لوحة بالأعلى للفحص والمطابقة الفورية"
                onDelete={handleDeleteRecord}
                onEditPlate={(id, val) => void handleEditPlate(id, val)}
              />
            </div>
          </div>
        )}

        {/* TAB: الكل */}
        {activeTab === 'all' && (
          <div className="space-y-4">
            <section className="rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="space-y-1">
                <h2 className="text-base font-extrabold text-[var(--text-primary)]">
                  السجل الكامل ({stats.total})
                </h2>
                <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--text-muted)] tabular-nums">
                  <span className="text-[#0d8a5f] dark:text-[#5eddaa] font-bold">
                    سليمة: {stats.valid}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-500 font-bold">مطلوبة: {stats.wanted}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-red-500 font-bold">خطأ: {stats.invalid}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={records.length === 0}
                  onClick={() => setExportOpen(true)}
                  className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#f0b942] px-4 py-2 text-sm font-extrabold text-[#06100c] hover:brightness-105 disabled:opacity-50"
                >
                  <Download className="h-4 w-4" aria-hidden="true" />
                  <span>تصدير Excel</span>
                </button>

                {!confirmClearAll ? (
                  <button
                    type="button"
                    disabled={records.length === 0}
                    onClick={() => setConfirmClearAll(true)}
                    className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-red-500/40 px-3.5 py-2 text-xs font-bold text-red-500 hover:bg-red-500/10 disabled:opacity-40"
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                    <span>مسح الكل</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setRecords([]);
                        setConfirmClearAll(false);
                      }}
                      className="min-h-[44px] rounded-xl bg-red-600 px-3.5 py-2 text-xs font-bold text-white"
                    >
                      تأكيد المسح
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClearAll(false)}
                      className="min-h-[44px] rounded-xl border border-[var(--border-hairline)] px-3 py-2 text-xs font-bold"
                    >
                      إلغاء
                    </button>
                  </div>
                )}
              </div>
            </section>

            <RecordsTable
              records={records}
              onDelete={handleDeleteRecord}
              onEditPlate={(id, val) => void handleEditPlate(id, val)}
            />
          </div>
        )}
      </main>

      {/* Thin 1-line Undo bar (6s) */}
      {undoItem && (
        <div
          role="status"
          className="fixed bottom-16 left-3 right-3 z-40 mx-auto flex h-10 max-w-md items-center justify-between rounded-xl border border-[#5eddaa]/40 bg-[#0c1c15] px-4 text-xs text-[#ecfdf5] shadow-lg"
        >
          <span className="truncate">
            تم حذف {formatPlateDisplay(undoItem.record.plate)}
          </span>
          <button
            type="button"
            onClick={handleUndoDelete}
            className="mr-3 shrink-0 font-extrabold text-[#f0b942] underline underline-offset-2"
          >
            تراجع
          </button>
        </div>
      )}

      {/* Bottom Navigation Bar (compact <= 56px) */}
      <nav
        aria-label="التنقل الرئيسي"
        className="fixed bottom-0 left-0 right-0 z-30 border-t border-[var(--border-hairline)] bg-[var(--bg-surface)]/95 backdrop-blur-md"
      >
        <div className="mx-auto grid h-14 max-w-5xl grid-cols-3">
          {(
            [
              { key: 'all', label: `الكل (${stats.total})` },
              { key: 'check', label: 'الفحص' },
              { key: 'manual', label: 'فحص يدوي' },
            ] as const
          ).map((tab) => {
            const active = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveTab(tab.key)}
                aria-current={active ? 'page' : undefined}
                className={`flex items-center justify-center text-xs sm:text-sm font-extrabold transition border-t-2 ${
                  active
                    ? 'border-[#f0b942] text-[#0d8a5f] dark:text-[#5eddaa] bg-[var(--bg-elevated)]/60'
                    : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                }`}
              >
                <span className="whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Modals */}
      <SettingsModal
        open={settingsOpen}
        settings={settings}
        watchlistCount={watchlistCount}
        zones={zones}
        importProgress={importProgress}
        onClose={() => setSettingsOpen(false)}
        onUploadWatchlistFile={(file) => void handleImportWatchlistBlob(file, file.name)}
        onPasteWatchlist={handlePasteWatchlist}
        onSaveZonesText={handleSaveZonesText}
        onClearZones={handleClearZones}
      />

      <WantedAlertModal
        plate={wantedAlert?.plate ?? ''}
        wantedData={wantedAlert?.data ?? null}
        onClose={() => setWantedAlert(null)}
      />

      <ExportModal
        open={exportOpen}
        isBusy={exportBusy}
        statusText={exportStatus}
        onShare={() => void handleExportShare()}
        onDownload={() => void handleExportDownload()}
        onClose={() => setExportOpen(false)}
      />

      <ColumnPickerModal
        pending={pendingColPicker}
        onCancel={() => setPendingColPicker(null)}
      />

      <RetroMatchModal
        matches={retroMatches?.matches ?? null}
        title={retroMatches?.title}
        onClose={() => setRetroMatches(null)}
      />
    </div>
  );
}
