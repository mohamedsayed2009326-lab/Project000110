import React, { useRef, useState } from 'react';
import { FileSpreadsheet, MapPin, Plus, Trash2, Upload, X } from 'lucide-react';
import type { AppSettings, GeoZone } from '../core/types';

interface SettingsModalProps {
  open: boolean;
  settings: AppSettings;
  watchlistCount: number;
  zones: GeoZone[];
  importProgress: { active: boolean; rowsScanned: number; importedCount: number; message: string };
  onClose: () => void;
  onUploadWatchlistFile: (file: File) => void;
  onPasteWatchlist: (text: string) => Promise<void>;
  onSaveZonesText: (text: string) => { added: number; updated: number; errors: string[] };
  onClearZones: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  settings,
  watchlistCount,
  zones,
  importProgress,
  onClose,
  onUploadWatchlistFile,
  onPasteWatchlist,
  onSaveZonesText,
  onClearZones,
}) => {
  const [showPasteBox, setShowPasteBox] = useState(false);
  const [pasteText, setPasteText] = useState('');
  const [zonesText, setZonesText] = useState('');
  const [zonesFeedback, setZonesFeedback] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!open) return null;

  const handlePasteSubmit = async () => {
    if (!pasteText.trim()) return;
    await onPasteWatchlist(pasteText);
    setPasteText('');
    setShowPasteBox(false);
  };

  const handleZonesSave = () => {
    if (!zonesText.trim()) return;
    const res = onSaveZonesText(zonesText);
    const parts: string[] = [];
    if (res.added > 0) parts.push(`تمت إضافة ${res.added} منطقة`);
    if (res.updated > 0) parts.push(`تم تحديث ${res.updated} منطقة`);
    if (res.errors.length > 0) parts.push(res.errors[0]);
    setZonesFeedback(parts.join(' · ') || 'لم يتم العثور على مناطق صالحة');
    if (res.added > 0 || res.updated > 0) setZonesText('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 sm:p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
    >
      <div className="flex max-h-[92vh] w-full max-w-lg flex-col rounded-t-3xl sm:rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[var(--border-hairline)] px-5 py-4">
          <h2 id="settings-modal-title" className="text-lg font-extrabold text-[var(--text-primary)]">
            الإعدادات
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق الإعدادات"
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-elevated)]"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto p-5">
          {/* Watchlist File (Excel / CSV + Paste) */}
          <section className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="h-4 w-4 text-[#5eddaa]" aria-hidden="true" />
                <h3 className="text-sm font-bold text-[var(--text-primary)]">ملف المطابقة (إكسل / CSV)</h3>
              </div>
              <span className="text-xs text-[var(--text-muted)] tabular-nums">
                {watchlistCount.toLocaleString('en-US')} لوحة محفوظة
              </span>
            </div>

            {settings.watchlistMeta && (
              <p className="text-xs text-[var(--text-muted)] break-words">
                آخر ملف: {settings.watchlistMeta.fileName} ·{' '}
                {new Date(settings.watchlistMeta.updatedAt).toLocaleString('ar-EG')}
              </p>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onUploadWatchlistFile(f);
                e.target.value = '';
              }}
            />

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                disabled={importProgress.active}
                onClick={() => fileInputRef.current?.click()}
                className="flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-[#f0b942] px-4 py-2.5 text-sm font-extrabold text-[#06100c] hover:brightness-105 disabled:opacity-60"
              >
                <Upload className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>تحديث الملف (استبدال)</span>
              </button>

              <button
                type="button"
                disabled={importProgress.active}
                onClick={() => setShowPasteBox((v) => !v)}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] px-4 py-2.5 text-sm font-bold text-[var(--text-primary)] hover:border-[#5eddaa]/50"
              >
                <Plus className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>لصق لوحات</span>
              </button>
            </div>

            {importProgress.active && (
              <div className="rounded-xl bg-[var(--bg-elevated)] p-3 text-xs text-[#0d8a5f] dark:text-[#5eddaa] tabular-nums">
                جاري القراءة التدفقية: تم فحص {importProgress.rowsScanned.toLocaleString('en-US')} صف · تم حفظ{' '}
                {importProgress.importedCount.toLocaleString('en-US')} لوحة...
              </div>
            )}

            {!importProgress.active && importProgress.message && (
              <div className="rounded-xl bg-[var(--bg-elevated)] p-3 text-xs text-[var(--text-primary)]">
                {importProgress.message}
              </div>
            )}

            {showPasteBox && (
              <div className="space-y-2 rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] p-3">
                <label htmlFor="paste-plates-box" className="block text-xs font-semibold text-[var(--text-muted)]">
                  الصق اللوحات (لوحة في كل سطر، ويمكن إضافة بيانات بعدها بعلامة | )
                </label>
                <textarea
                  id="paste-plates-box"
                  rows={4}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder={'رحم3249\nب ح هـ 324 | بنك مصر'}
                  className="w-full rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-canvas)] p-2.5 text-sm text-[var(--text-primary)] outline-none focus:border-[#5eddaa]"
                />
                <button
                  type="button"
                  onClick={() => void handlePasteSubmit()}
                  className="min-h-[44px] w-full rounded-xl bg-[#0d8a5f] dark:bg-[#5eddaa] px-4 py-2 text-sm font-extrabold text-white dark:text-[#06100c]"
                >
                  إضافة للملف وفحص السجل
                </button>
              </div>
            )}
          </section>

          <hr className="border-[var(--border-hairline)]" />

          {/* 3. Named Geo Zones */}
          <section className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-[#5eddaa]" aria-hidden="true" />
                <h3 className="text-sm font-bold text-[var(--text-primary)]">المناطق المسمّاة</h3>
              </div>
              <span className="text-xs text-[var(--text-muted)] tabular-nums">
                {zones.length} منطقة
              </span>
            </div>

            <label htmlFor="zones-textarea" className="block text-xs leading-relaxed text-[var(--text-muted)]">
              الصق كل منطقة: سطر الاسم، وتحته 4 أسطر (خط العرض, خط الطول)، وسطر فاضي بين كل منطقة.
            </label>
            <textarea
              id="zones-textarea"
              rows={5}
              value={zonesText}
              onChange={(e) => setZonesText(e.target.value)}
              dir="auto"
              placeholder={'جني — الرمال\n30.0123, 31.2345\n30.0123, 31.2450\n30.0050, 31.2450\n30.0050, 31.2345'}
              className="w-full rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] p-3 text-xs leading-relaxed text-[var(--text-primary)] outline-none focus:border-[#5eddaa]"
            />

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleZonesSave}
                className="min-h-[44px] flex-1 rounded-xl bg-[#0d8a5f] dark:bg-[#5eddaa] px-4 py-2 text-sm font-extrabold text-white dark:text-[#06100c]"
              >
                حفظ وتطبيق على السجل
              </button>
              {zones.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    onClearZones();
                    setZonesFeedback('تم مسح جميع المناطق');
                  }}
                  className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-red-500/40 px-3.5 py-2 text-xs font-bold text-red-500 hover:bg-red-500/10"
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" />
                  <span>مسح الكل</span>
                </button>
              )}
            </div>

            {zonesFeedback && (
              <p className="text-xs font-semibold text-[#0d8a5f] dark:text-[#5eddaa]">{zonesFeedback}</p>
            )}

            {zones.length > 0 && (
              <div className="text-xs text-[var(--text-muted)] break-words">
                المناطق المحفوظة: {zones.map((z) => z.name).join(' · ')}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
