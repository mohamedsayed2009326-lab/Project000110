import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { formatPlateDisplay } from '../core/plateParser';
import type { WatchlistEntry } from '../core/types';

interface WantedAlertModalProps {
  plate: string;
  wantedData: WatchlistEntry | null;
  onClose: () => void;
}

export const WantedAlertModal: React.FC<WantedAlertModalProps> = ({
  plate,
  wantedData,
  onClose,
}) => {
  if (!wantedData) return null;

  const entries = Object.entries(wantedData.extra ?? {});

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="wanted-alert-title"
    >
      <div className="w-full max-w-md rounded-2xl border-2 border-amber-400 bg-[var(--bg-surface)] p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5 text-amber-500">
            <AlertTriangle className="h-7 w-7 shrink-0" aria-hidden="true" />
            <h2 id="wanted-alert-title" className="text-2xl font-extrabold">
              مطلوبة!
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق تنبيه المطلوبة"
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-elevated)]"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="my-4 rounded-xl border border-amber-400/40 bg-amber-500/10 py-3 text-center">
          <div className="font-plate text-3xl font-extrabold tracking-widest text-[var(--text-primary)]">
            {formatPlateDisplay(plate)}
          </div>
        </div>

        <div className="max-h-60 space-y-2 overflow-y-auto rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] p-3 text-sm">
          {entries.length > 0 ? (
            entries.map(([k, v]) => (
              <div key={k} className="flex items-start justify-between gap-3 border-b border-[var(--border-hairline)] pb-1.5 last:border-b-0 last:pb-0">
                <span className="font-bold text-[var(--text-muted)] shrink-0">{k}:</span>
                <span className="text-left font-semibold text-[var(--text-primary)] break-words">{v}</span>
              </div>
            ))
          ) : (
            <p className="text-[var(--text-primary)] break-words">{wantedData.rawSummary}</p>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 flex min-h-[48px] w-full items-center justify-center rounded-xl bg-[#f0b942] px-4 py-3 text-base font-extrabold text-[#06100c] hover:brightness-105 transition"
        >
          فهمت — إغلاق التنبيه
        </button>
      </div>
    </div>
  );
};
