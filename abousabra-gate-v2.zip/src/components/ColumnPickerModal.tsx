import React from 'react';
import { Columns, X } from 'lucide-react';
import type { PendingColumnSelection } from '../core/types';

interface ColumnPickerModalProps {
  pending: PendingColumnSelection | null;
  onCancel: () => void;
}

export const ColumnPickerModal: React.FC<ColumnPickerModalProps> = ({
  pending,
  onCancel,
}) => {
  if (!pending) return null;

  const colCount = Math.max(
    pending.headers.length,
    ...pending.samples.map((r) => r.length),
    0
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="col-picker-title"
    >
      <div className="w-full max-w-md rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Columns className="h-5 w-5 text-[#5eddaa]" aria-hidden="true" />
            <h2 id="col-picker-title" className="text-base font-extrabold text-[var(--text-primary)]">
              اختر عمود رقم اللوحة
            </h2>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="إلغاء اختيار العمود"
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-elevated)]"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <p className="mt-1.5 text-xs text-[var(--text-muted)]">
          لم نتمكن من تحديد عمود اللوحات تلقائياً في ({pending.fileName}). اختر العمود الصحيح من القائمة:
        </p>

        <div className="mt-4 max-h-72 space-y-2 overflow-y-auto">
          {Array.from({ length: colCount }).map((_, idx) => {
            const header = pending.headers[idx] || `عمود ${idx + 1}`;
            const examples = pending.samples
              .map((r) => (r[idx] ?? '').trim())
              .filter(Boolean)
              .slice(0, 3);

            return (
              <button
                key={idx}
                type="button"
                onClick={() => void pending.onSelectColumn(idx)}
                className="w-full rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] p-3 text-right hover:border-[#5eddaa] transition"
              >
                <div className="text-sm font-bold text-[var(--text-primary)]">{header}</div>
                <div className="mt-1 text-xs text-[var(--text-muted)] break-words">
                  أمثلة: {examples.length > 0 ? examples.join(' · ') : 'فارغ'}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
