import React from 'react';

interface SplashOverlayProps {
  visible: boolean;
}

export const SplashOverlay: React.FC<SplashOverlayProps> = ({ visible }) => {
  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#06100c] text-[#ecfdf5] transition-opacity duration-300"
      role="status"
      aria-label="جاري تحميل بوابة ابو صبره"
    >
      <div className="flex flex-col items-center gap-4 px-6 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-2xl border border-[#5eddaa]/30 bg-[#0c1c15]">
          <svg
            viewBox="0 0 64 64"
            className="h-12 w-12 text-[#5eddaa]"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M12 52V22a20 20 0 0 1 40 0v30" />
            <path d="M6 52h52" />
            <path d="M22 52V30a10 10 0 0 1 20 0v22" />
            <circle cx="32" cy="18" r="3" fill="#f0b942" stroke="none" />
          </svg>
        </div>
        <h1 className="text-2xl font-extrabold tracking-tight text-[#5eddaa]">
          بوابة ابو صبره
        </h1>
        <p className="text-sm text-[#8cb8a4]">التشييك الصوتي الفوري للمركبات</p>
      </div>
    </div>
  );
};
