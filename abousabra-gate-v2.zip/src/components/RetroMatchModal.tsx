import React from 'react';
import { AlertTriangle, MapPin, X } from 'lucide-react';
import { formatPlateDisplay } from '../core/plateParser';
import { buildGoogleMapsUrl } from '../core/geoZones';
import type { PlateRecord } from '../core/types';

interface RetroMatchModalProps {
  matches: PlateRecord[] | null;
  title?: string;
  onClose: () => void;
}

export const RetroMatchModal: React.FC<RetroMatchModalProps> = ({
  matches,
  title,
  onClose,
}) => {
  if (!matches) return null;

  const heading = title ?? `لقيت ${matches.length} لوحة مطلوبة في السجل`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="retro-match-title"
    >
      <div className="flex max-h-[85vh] w-full max-w-lg flex-col rounded-2xl border border-amber-400/50 bg-[var(--bg-surface)] p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-amber-500">
            <AlertTriangle className="h-5 w-5 shrink-0" aria-hidden="true" />
            <h2 id="retro-match-title" className="text-base font-extrabold">
              {heading}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق قائمة المطابقة"
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-elevated)]"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-3 flex-1 space-y-2.5 overflow-y-auto">
          {matches.length === 0 ? (
            <p className="py-6 text-center text-sm text-[var(--text-muted)]">
              لا توجد لوحات مطلوبة في السجل الحالي.
            </p>
          ) : (
            matches.map((rec) => {
              const timeStr = new Date(rec.timestamp).toLocaleTimeString('ar-EG', {
                hour: '2-digit',
                minute: '2-digit',
              });
              const hasCoords = rec.lat !== undefined && rec.lng !== undefined;
              return (
                <div
                  key={rec.id}
                  className="rounded-xl border border-amber-400/30 bg-amber-500/10 p-3 text-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-plate text-base font-extrabold text-[var(--text-primary)]">
                        {formatPlateDisplay(rec.plate)}
                      </span>
                      {rec.isNewMatch && (
                        <span className="text-xs font-extrabold text-amber-500">· جديدة</span>
                      )}
                    </div>
                    <span className="text-xs text-[var(--text-muted)] tabular-nums">{timeStr}</span>
                  </div>

                  {rec.wantedData?.rawSummary && (
                    <p className="mt-1 text-xs text-amber-700 dark:text-amber-300 break-words">
                      {rec.wantedData.rawSummary}
                    </p>
                  )}

                  {(rec.locationName || hasCoords) && (
                    <div className="mt-1.5 text-xs">
                      {hasCoords ? (
                        <a
                          href={buildGoogleMapsUrl(rec.lat!, rec.lng!)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[#0d8a5f] dark:text-[#5eddaa] underline decoration-dotted"
                        >
                          <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>{rec.locationName || `${rec.lat!.toFixed(4)}, ${rec.lng!.toFixed(4)}`}</span>
                        </a>
                      ) : (
                        <span className="text-[var(--text-muted)]">{rec.locationName}</span>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 min-h-[44px] w-full rounded-xl bg-[#f0b942] px-4 py-2.5 text-sm font-extrabold text-[#06100c]"
        >
          تم
        </button>
      </div>
    </div>
  );
};
