import React, { useEffect, useState } from 'react';
import { X, MapPin, Pencil } from 'lucide-react';
import { formatPlateDisplay } from '../core/plateParser';
import { buildGoogleMapsUrl } from '../core/geoZones';
import type { PlateRecord } from '../core/types';

interface RecordsTableProps {
  records: PlateRecord[];
  emptyMessage?: string;
  onDelete: (id: string) => void;
  onEditPlate: (id: string, newRawPlate: string) => void;
}

function useIsDesktop(minWidthPx = 640): boolean {
  const [isDesktop, setIsDesktop] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia(`(min-width: ${minWidthPx}px)`).matches
      : false
  );

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia(`(min-width: ${minWidthPx}px)`);
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, [minWidthPx]);

  return isDesktop;
}

export const RecordsTable: React.FC<RecordsTableProps> = ({
  records,
  emptyMessage = 'لا توجد لوحات مسجلة بعد',
  onDelete,
  onEditPlate,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const isDesktop = useIsDesktop(640);

  const startEdit = (rec: PlateRecord) => {
    setEditingId(rec.id);
    setEditValue(formatPlateDisplay(rec.plate));
  };

  const commitEdit = (id: string) => {
    if (editValue.trim()) {
      onEditPlate(id, editValue);
    }
    setEditingId(null);
  };

  if (records.length === 0) {
    return (
      <div className="rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] px-4 py-10 text-center text-sm text-[var(--text-muted)]">
        {emptyMessage}
      </div>
    );
  }

  if (!isDesktop) {
    return (
      <div className="w-full overflow-hidden rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] divide-y divide-[var(--border-hairline)]">
        {records.map((rec, idx) => {
          const rowNumber = records.length - idx;
          const isEditing = editingId === rec.id;
          const hasCoords = rec.lat !== undefined && rec.lng !== undefined;
          const mapHref = hasCoords ? buildGoogleMapsUrl(rec.lat!, rec.lng!) : null;
          const locationLabel =
            rec.locationName ||
            (hasCoords ? `${rec.lat!.toFixed(4)}, ${rec.lng!.toFixed(4)}` : '—');

          const rowTone =
            rec.status === 'wanted'
              ? 'bg-amber-500/15'
              : rec.status === 'invalid'
              ? 'bg-red-100/90 dark:bg-red-500/25'
              : '';

          return (
            <div key={rec.id} className={`px-3 py-2.5 space-y-1.5 ${rowTone}`}>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="font-mono text-xs font-bold text-[var(--text-muted)] tabular-nums shrink-0">
                    #{rowNumber}
                  </span>

                  {isEditing ? (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        commitEdit(rec.id);
                      }}
                      className="flex items-center"
                    >
                      <input
                        type="text"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={() => commitEdit(rec.id)}
                        autoFocus
                        aria-label={`تعديل اللوحة ${rec.plate}`}
                        className="w-48 rounded-lg border border-emerald-500 bg-[var(--bg-canvas)] px-2.5 py-1.5 font-plate text-2xl font-black text-[var(--text-primary)] outline-none"
                      />
                    </form>
                  ) : (
                    <button
                      type="button"
                      onClick={() => startEdit(rec)}
                      aria-label={`تعديل اللوحة ${formatPlateDisplay(rec.plate)}`}
                      className={`group inline-flex min-h-[48px] items-center gap-1.5 rounded-xl px-1.5 py-1 text-right font-plate text-[34px] leading-none font-black tracking-wider hover:bg-[var(--bg-elevated)]/70 ${
                        rec.status === 'invalid'
                          ? 'text-red-700 dark:text-red-200'
                          : 'text-[var(--text-primary)]'
                      }`}
                    >
                      <span className="whitespace-nowrap">{formatPlateDisplay(rec.plate)}</span>
                      <Pencil
                        className="h-3.5 w-3.5 opacity-35 group-hover:opacity-100 shrink-0"
                        aria-hidden="true"
                      />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {rec.status === 'wanted' ? (
                    <span className="text-xs font-extrabold text-amber-600 dark:text-amber-400 whitespace-nowrap">
                      مطلوبة ⚠
                    </span>
                  ) : rec.status === 'invalid' ? (
                    <span className="text-xs font-extrabold text-red-700 dark:text-red-300 whitespace-nowrap">
                      خطأ !
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-[#0d8a5f] dark:text-[#5eddaa] whitespace-nowrap">
                      سليمة ✓
                    </span>
                  )}

                  <button
                    type="button"
                    onClick={() => onDelete(rec.id)}
                    aria-label={`حذف اللوحة ${rec.plate}`}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-[var(--text-muted)] hover:bg-red-500/15 hover:text-red-500 transition-colors"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[var(--text-muted)] pr-6">
                <span className="font-semibold text-[var(--text-primary)]">
                  النوع: {rec.vehicleType || '—'}
                </span>
                <span aria-hidden="true">·</span>
                {mapHref ? (
                  <a
                    href={mapHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#0d8a5f] dark:text-[#5eddaa] underline decoration-dotted underline-offset-4 hover:opacity-80 break-words"
                  >
                    <MapPin className="h-3 w-3 shrink-0" aria-hidden="true" />
                    <span>{locationLabel}</span>
                  </a>
                ) : (
                  <span>الموقع: {locationLabel}</span>
                )}
              </div>

              {rec.status === 'wanted' && rec.wantedData && (
                <div className="pr-6 text-xs text-amber-700 dark:text-amber-300 break-words">
                  <span className="font-bold">بيانات المطلوب: </span>
                  <span>{rec.wantedData.rawSummary}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="w-full overflow-x-auto rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)]">
      <table className="w-full border-collapse text-right text-sm">
        <thead>
          <tr className="border-b border-[var(--border-hairline)] bg-[var(--bg-elevated)] text-xs font-bold text-[var(--text-muted)]">
            <th className="px-2.5 py-2.5 text-center w-10">#</th>
            <th className="px-3 py-2.5 whitespace-nowrap">اللوحة</th>
            <th className="px-2.5 py-2.5 whitespace-nowrap">النوع</th>
            <th className="px-2.5 py-2.5">الموقع</th>
            <th className="px-2.5 py-2.5 whitespace-nowrap">الحالة</th>
            <th className="px-2 py-2.5 text-center w-12">✕</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[var(--border-hairline)]">
          {records.map((rec, idx) => {
            const rowNumber = records.length - idx;
            const isEditing = editingId === rec.id;
            const hasCoords = rec.lat !== undefined && rec.lng !== undefined;
            const mapHref = hasCoords ? buildGoogleMapsUrl(rec.lat!, rec.lng!) : null;
            const locationLabel =
              rec.locationName ||
              (hasCoords ? `${rec.lat!.toFixed(4)}, ${rec.lng!.toFixed(4)}` : '—');

            return (
              <React.Fragment key={rec.id}>
                <tr
                  className={
                    rec.status === 'wanted'
                      ? 'bg-amber-500/15 hover:bg-amber-500/20'
                      : rec.status === 'invalid'
                      ? 'bg-red-100/90 dark:bg-red-500/25 hover:bg-red-200/75 dark:hover:bg-red-500/30'
                      : 'hover:bg-[var(--bg-elevated)]/50'
                  }
                >
                  <td className="px-2.5 py-2 text-center font-mono text-xs text-[var(--text-muted)] tabular-nums">
                    {rowNumber}
                  </td>

                  <td className="px-3 py-2">
                    {isEditing ? (
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          commitEdit(rec.id);
                        }}
                        className="flex items-center gap-1"
                      >
                        <input
                          type="text"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={() => commitEdit(rec.id)}
                          autoFocus
                          aria-label={`تعديل اللوحة ${rec.plate}`}
                          className="w-56 rounded-lg border border-emerald-500 bg-[var(--bg-canvas)] px-3 py-1.5 font-plate text-3xl font-black text-[var(--text-primary)] outline-none"
                        />
                      </form>
                    ) : (
                      <button
                        type="button"
                        onClick={() => startEdit(rec)}
                        aria-label={`تعديل اللوحة ${formatPlateDisplay(rec.plate)}`}
                        className={`group inline-flex min-h-[52px] items-center gap-2 rounded-xl px-2 py-1 text-right font-plate text-4xl leading-none font-black tracking-wider hover:bg-[var(--bg-elevated)]/70 ${
                          rec.status === 'invalid'
                            ? 'text-red-700 dark:text-red-200'
                            : 'text-[var(--text-primary)]'
                        }`}
                      >
                        <span className="whitespace-nowrap">{formatPlateDisplay(rec.plate)}</span>
                        <Pencil className="h-4 w-4 opacity-35 group-hover:opacity-100 shrink-0" aria-hidden="true" />
                      </button>
                    )}
                  </td>

                  <td className="px-2.5 py-2 text-xs font-semibold text-[var(--text-primary)] whitespace-nowrap">
                    {rec.vehicleType || '—'}
                  </td>

                  <td className="px-2.5 py-2 text-xs leading-snug break-words max-w-[180px]">
                    {mapHref ? (
                      <a
                        href={mapHref}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-start gap-1 text-[#0d8a5f] dark:text-[#5eddaa] underline decoration-dotted underline-offset-4 hover:opacity-80"
                      >
                        <MapPin className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
                        <span className="break-words">{locationLabel}</span>
                      </a>
                    ) : (
                      <span className="text-[var(--text-muted)]">{locationLabel}</span>
                    )}
                  </td>

                  <td className="px-2.5 py-2 whitespace-nowrap">
                    {rec.status === 'wanted' ? (
                      <span className="font-bold text-amber-600 dark:text-amber-400">
                        مطلوبة ⚠
                      </span>
                    ) : rec.status === 'invalid' ? (
                      <span className="font-extrabold text-red-700 dark:text-red-300">
                        خطأ !
                      </span>
                    ) : (
                      <span className="font-bold text-[#0d8a5f] dark:text-[#5eddaa]">
                        سليمة ✓
                      </span>
                    )}
                  </td>

                  <td className="px-2 py-2 text-center">
                    <button
                      type="button"
                      onClick={() => onDelete(rec.id)}
                      aria-label={`حذف اللوحة ${rec.plate}`}
                      className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-[var(--text-muted)] hover:bg-red-500/15 hover:text-red-500 transition-colors"
                    >
                      <X className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </td>
                </tr>

                {rec.status === 'wanted' && rec.wantedData && (
                  <tr className="bg-amber-500/15">
                    <td colSpan={6} className="px-3 pb-2.5 pt-0.5 text-xs text-amber-700 dark:text-amber-300 break-words">
                      <span className="font-bold">بيانات المطلوب: </span>
                      <span>{rec.wantedData.rawSummary}</span>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
