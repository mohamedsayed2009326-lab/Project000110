import React from 'react';
import { X } from 'lucide-react';

interface ExportModalProps {
  open: boolean;
  isBusy: boolean;
  statusText: string;
  onShare: () => void;
  onDownload: () => void;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  open,
  isBusy,
  statusText,
  onShare,
  onDownload,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="export-modal-title"
    >
      <div className="w-full max-w-sm rounded-2xl border border-[var(--border-hairline)] bg-[var(--bg-surface)] p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-2">
          <h2 id="export-modal-title" className="text-lg font-extrabold text-[var(--text-primary)]">
            تصدير السجل (Excel)
          </h2>
          <button
            type="button"
            onClick={onClose}
            disabled={isBusy}
            aria-label="إغلاق نافذة التصدير"
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-elevated)] disabled:opacity-50"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <p className="mt-2 text-xs leading-relaxed text-[var(--text-muted)]">
          يتم تصدير ملف إكسل RTL شامل اللوحات بدون مسافات وروابط خرائط جوجل لأسماء الأحياء والمناطق.
        </p>

        {statusText && (
          <div className="mt-3 rounded-xl bg-[var(--bg-elevated)] px-3 py-2 text-xs font-semibold text-[#0d8a5f] dark:text-[#5eddaa]">
            {statusText}
          </div>
        )}

        <div className="mt-4 flex flex-col gap-3">
          <button
            type="button"
            onClick={onShare}
            disabled={isBusy}
            className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#f0b942] px-4 py-3 text-sm font-extrabold text-[#06100c] hover:brightness-105 disabled:opacity-60 transition"
          >
            <span>📤 مشاركة (من غير تنزيل)</span>
          </button>

          <button
            type="button"
            onClick={onDownload}
            disabled={isBusy}
            className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl border border-[var(--border-hairline)] bg-[var(--bg-elevated)] px-4 py-3 text-sm font-bold text-[var(--text-primary)] hover:border-[#5eddaa]/50 disabled:opacity-60 transition"
          >
            <span>⬇️ تنزيل في Downloads</span>
          </button>
        </div>
      </div>
    </div>
  );
};
