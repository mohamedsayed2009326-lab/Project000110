export type LiveSessionState =
  | 'idle'
  | 'connecting'
  | 'listening'
  | 'paused'
  | 'reconnecting'
  | 'error';

export type SignalQuality = 'ضعيف' | 'متوسط' | 'قوي';

export interface GeminiLiveCallbacks {
  onStateChange: (state: LiveSessionState) => void;
  onInterimText: (text: string) => void;
  onCommittedText: (text: string) => void;
  onTurnComplete: () => void;
  onAudioLevel: (percent: number, signal: SignalQuality) => void;
  onError: (message: string) => void;
}

const TARGET_SAMPLE_RATE = 16000;
const CHUNK_SAMPLES = 2048; // 2048 / 16000 = 128ms
const RECONNECT_BEFORE_MS = 9 * 60 * 1000 + 20 * 1000; // 9m20s seamless rotate before 10m limit

function downsampleFloat32(
  input: Float32Array,
  inputRate: number,
  targetRate: number
): Float32Array {
  if (inputRate === targetRate) return input;
  const ratio = inputRate / targetRate;
  const newLen = Math.max(1, Math.round(input.length / ratio));
  const out = new Float32Array(newLen);
  let offsetResult = 0;
  let offsetBuffer = 0;
  while (offsetResult < newLen) {
    const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    let accum = 0;
    let count = 0;
    for (let i = offsetBuffer; i < nextOffsetBuffer && i < input.length; i++) {
      accum += input[i];
      count++;
    }
    out[offsetResult] = count > 0 ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return out;
}

function floatTo16BitPcmBase64(samples: Float32Array): string {
  const buf = new ArrayBuffer(samples.length * 2);
  const view = new DataView(buf);
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  const bytes = new Uint8Array(buf);
  let binary = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode(...bytes.subarray(i, i + step));
  }
  return btoa(binary);
}

export class GeminiLiveClient {
  private callbacks: GeminiLiveCallbacks;
  private ws: WebSocket | null = null;
  private setupComplete = false;
  private isPaused = false;
  private intentionallyClosed = false;
  private stream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private pcmQueue: Float32Array[] = [];
  private pcmQueuedSamples = 0;
  private rotateTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(callbacks: GeminiLiveCallbacks) {
    this.callbacks = callbacks;
  }

  public async start(): Promise<void> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      const msg = 'الميكروفون غير متاح في هذا السياق. تأكد من فتح الصفحة عبر HTTPS ومنح صلاحية الميكروفون.';
      this.callbacks.onError(msg);
      this.callbacks.onStateChange('error');
      return;
    }

    this.intentionallyClosed = false;
    this.isPaused = false;
    this.callbacks.onStateChange('connecting');

    try {
      await this.initMicrophone();
      await this.connectWebSocket(false);
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.name === 'NotAllowedError'
            ? 'تم رفض صلاحية الميكروفون. اسمح للتطبيق بالوصول للميكروفون.'
            : err.message
          : 'تعذر تشغيل الميكروفون.';
      this.callbacks.onError(msg);
      this.callbacks.onStateChange('error');
      this.cleanupAudio();
    }
  }

  public pause(): void {
    this.isPaused = true;
    this.callbacks.onStateChange('paused');
    this.callbacks.onAudioLevel(0, 'ضعيف');
  }

  public resume(): void {
    if (this.intentionallyClosed) return;
    this.isPaused = false;
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.setupComplete) {
      this.callbacks.onStateChange('listening');
    } else {
      this.callbacks.onStateChange('reconnecting');
      void this.connectWebSocket(true);
    }
  }

  public stop(): void {
    this.intentionallyClosed = true;
    this.isPaused = false;
    if (this.rotateTimer) {
      clearTimeout(this.rotateTimer);
      this.rotateTimer = null;
    }
    this.closeWebSocketOnly();
    this.cleanupAudio();
    this.callbacks.onAudioLevel(0, 'ضعيف');
    this.callbacks.onInterimText('');
    this.callbacks.onStateChange('idle');
  }

  private async initMicrophone(): Promise<void> {
    if (this.stream && this.audioCtx) return;

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    const AudioCtxCtor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;

    try {
      this.audioCtx = new AudioCtxCtor({ sampleRate: TARGET_SAMPLE_RATE });
    } catch {
      this.audioCtx = new AudioCtxCtor();
    }

    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }

    this.sourceNode = this.audioCtx.createMediaStreamSource(this.stream);
    this.processor = this.audioCtx.createScriptProcessor(2048, 1, 1);

    const muteGain = this.audioCtx.createGain();
    muteGain.gain.value = 0;

    this.sourceNode.connect(this.processor);
    this.processor.connect(muteGain);
    muteGain.connect(this.audioCtx.destination);

    this.processor.onaudioprocess = (ev) => {
      if (this.intentionallyClosed || this.isPaused) return;
      const input = ev.inputBuffer.getChannelData(0);

      let sumSq = 0;
      for (let i = 0; i < input.length; i++) {
        sumSq += input[i] * input[i];
      }
      const rms = Math.sqrt(sumSq / input.length);
      const pct = Math.min(100, Math.round(rms * 420));
      const signal: SignalQuality = pct >= 45 ? 'قوي' : pct >= 15 ? 'متوسط' : 'ضعيف';
      this.callbacks.onAudioLevel(pct, signal);

      if (!this.setupComplete || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return;
      }

      const resampled = downsampleFloat32(
        input,
        this.audioCtx?.sampleRate ?? TARGET_SAMPLE_RATE,
        TARGET_SAMPLE_RATE
      );

      this.pcmQueue.push(resampled);
      this.pcmQueuedSamples += resampled.length;

      while (this.pcmQueuedSamples >= CHUNK_SAMPLES) {
        const chunk = new Float32Array(CHUNK_SAMPLES);
        let written = 0;
        while (written < CHUNK_SAMPLES && this.pcmQueue.length > 0) {
          const head = this.pcmQueue[0];
          const needed = CHUNK_SAMPLES - written;
          if (head.length <= needed) {
            chunk.set(head, written);
            written += head.length;
            this.pcmQueue.shift();
          } else {
            chunk.set(head.subarray(0, needed), written);
            this.pcmQueue[0] = head.subarray(needed);
            written += needed;
          }
        }
        this.pcmQueuedSamples -= CHUNK_SAMPLES;

        const base64 = floatTo16BitPcmBase64(chunk);
        this.ws.send(JSON.stringify({ type: 'audio', data: base64 }));
      }
    };
  }

  private connectWebSocket(isReconnect: boolean): Promise<void> {
    return new Promise((resolve, reject) => {
      this.closeWebSocketOnly();
      this.setupComplete = false;
      const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url = `${wsProto}//${window.location.host}/api/live`;

      let settled = false;
      let lastServerError = '';
      const ws = new WebSocket(url);
      this.ws = ws;

      ws.onmessage = async (event) => {
        try {
          const raw = event.data instanceof Blob ? await event.data.text() : String(event.data);
          const msg = JSON.parse(raw) as { type?: string; text?: string; message?: string };

          if (msg.type === 'ready') {
            this.setupComplete = true;
            settled = true;
            this.callbacks.onStateChange(this.isPaused ? 'paused' : 'listening');

            if (this.rotateTimer) clearTimeout(this.rotateTimer);
            this.rotateTimer = setTimeout(() => {
              if (!this.intentionallyClosed) {
                this.callbacks.onStateChange('reconnecting');
                void this.connectWebSocket(true);
              }
            }, RECONNECT_BEFORE_MS);

            resolve();
            return;
          }

          if (msg.type === 'interim' && msg.text) {
            this.callbacks.onInterimText(msg.text);
            return;
          }

          if (msg.type === 'transcript' && msg.text) {
            this.callbacks.onInterimText('');
            this.callbacks.onCommittedText(msg.text);
            return;
          }

          if (msg.type === 'turnComplete') {
            this.callbacks.onTurnComplete();
            return;
          }

          if (msg.type === 'error' && msg.message) {
            lastServerError = msg.message;
            this.callbacks.onError(msg.message);
          }
        } catch {
          // Ignore malformed frames
        }
      };

      ws.onerror = () => {
        if (!settled && !isReconnect) {
          settled = true;
          reject(new Error('تعذر الاتصال بخادم الصوت. تحقق من الإنترنت.'));
        }
      };

      ws.onclose = (ev) => {
        if (this.ws !== ws) return;
        const wasSetup = this.setupComplete;
        this.setupComplete = false;

        if (this.intentionallyClosed) return;

        if (!wasSetup) {
          const errMsg = lastServerError || ev.reason || 'تعذر بدء جلسة الصوت عبر الخادم.';
          this.callbacks.onError(errMsg);
          this.callbacks.onStateChange('error');
          if (!settled) {
            settled = true;
            reject(new Error(errMsg));
          }
          return;
        }

        // Seamless auto-reconnect on ~10-minute session limit
        this.callbacks.onStateChange('reconnecting');
        setTimeout(() => {
          if (!this.intentionallyClosed) {
            void this.connectWebSocket(true).catch((e) => {
              this.callbacks.onError(e instanceof Error ? e.message : 'انقطع الاتصال');
              this.callbacks.onStateChange('error');
            });
          }
        }, 700);
      };
    });
  }

  private closeWebSocketOnly(): void {
    if (this.ws) {
      const old = this.ws;
      this.ws = null;
      old.onopen = null;
      old.onmessage = null;
      old.onerror = null;
      old.onclose = null;
      try {
        old.close();
      } catch {
        // Ignore
      }
    }
  }

  private cleanupAudio(): void {
    this.pcmQueue = [];
    this.pcmQueuedSamples = 0;
    if (this.processor) {
      this.processor.disconnect();
      this.processor.onaudioprocess = null;
      this.processor = null;
    }
    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }
    if (this.audioCtx) {
      void this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
    if (this.stream) {
      for (const t of this.stream.getTracks()) {
        t.stop();
      }
      this.stream = null;
    }
  }
}
