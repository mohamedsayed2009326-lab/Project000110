export interface AndroidBridgeInterface {
  saveStart(fileName: string, mimeType: string): void;
  saveChunk(base64Chunk: string): void;
  saveEnd(): string;
  shareStart(fileName: string, mimeType: string): void;
  shareChunk(base64Chunk: string): void;
  shareEnd(): string;
  hasSharedImportFile?: () => boolean;
  getSharedImportFileName?: () => string;
  clearSharedImportFile?: () => void;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeInterface;
    onSharedFileAvailable?: (fileName: string) => void;
  }
}

const CHUNK_RAW_BYTES = 384 * 1024; // ~512KB in base64 (384KB * 4/3 = 512KB)

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode(...bytes.subarray(i, i + step));
  }
  return btoa(binary);
}

export function isAndroidWebView(): boolean {
  return typeof window !== 'undefined' && Boolean(window.AndroidBridge);
}

export async function exportViaSaveDownloads(
  bytes: Uint8Array,
  fileName: string
): Promise<void> {
  const mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

  if (window.AndroidBridge) {
    window.AndroidBridge.saveStart(fileName, mime);
    for (let offset = 0; offset < bytes.length; offset += CHUNK_RAW_BYTES) {
      const slice = bytes.subarray(offset, Math.min(bytes.length, offset + CHUNK_RAW_BYTES));
      window.AndroidBridge.saveChunk(bytesToBase64(slice));
    }
    window.AndroidBridge.saveEnd();
    return;
  }

  // Web browser fallback
  const blob = new Blob([bytes.buffer as ArrayBuffer], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

export async function exportViaShare(
  bytes: Uint8Array,
  fileName: string
): Promise<void> {
  const mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

  if (window.AndroidBridge) {
    window.AndroidBridge.shareStart(fileName, mime);
    for (let offset = 0; offset < bytes.length; offset += CHUNK_RAW_BYTES) {
      const slice = bytes.subarray(offset, Math.min(bytes.length, offset + CHUNK_RAW_BYTES));
      window.AndroidBridge.shareChunk(bytesToBase64(slice));
    }
    window.AndroidBridge.shareEnd();
    return;
  }

  // Web browser fallback (Web Share API if supported, else download)
  const file = new File([bytes.buffer as ArrayBuffer], fileName, { type: mime });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    await navigator.share({
      files: [file],
      title: 'سجل بوابة ابو صبره',
    });
    return;
  }

  await exportViaSaveDownloads(bytes, fileName);
}

export async function fetchAndroidSharedImportFile(): Promise<{ blob: Blob; fileName: string } | null> {
  if (!window.AndroidBridge?.hasSharedImportFile?.()) return null;
  try {
    const fileName = window.AndroidBridge.getSharedImportFileName?.() || 'shared_watchlist.xlsx';
    const res = await fetch('https://appassets.androidplatform.net/shared/file');
    if (!res.ok) return null;
    const blob = await res.blob();
    window.AndroidBridge.clearSharedImportFile?.();
    return { blob, fileName };
  } catch {
    return null;
  }
}

export function triggerWantedFeedback(plateText: string): void {
  // Vibrate
  if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    try {
      navigator.vibrate([250, 100, 250, 100, 400]);
    } catch {
      // Ignore
    }
  }

  // Speech synthesis ar-SA
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(`مطلوبة! ${plateText}`);
      utter.lang = 'ar-SA';
      utter.rate = 0.95;
      window.speechSynthesis.speak(utter);
    } catch {
      // Ignore
    }
  }
}
