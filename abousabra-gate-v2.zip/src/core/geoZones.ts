import type { GeoPoint, GeoZone } from './types';

function computeCentroid(points: GeoPoint[]): GeoPoint {
  const sum = points.reduce(
    (acc, p) => ({ lat: acc.lat + p.lat, lng: acc.lng + p.lng }),
    { lat: 0, lng: 0 }
  );
  return { lat: sum.lat / points.length, lng: sum.lng / points.length };
}

export function sortPolygonVertices(points: GeoPoint[]): GeoPoint[] {
  if (points.length <= 2) return points;
  const c = computeCentroid(points);
  return [...points].sort((a, b) => {
    const angA = Math.atan2(a.lat - c.lat, a.lng - c.lng);
    const angB = Math.atan2(b.lat - c.lat, b.lng - c.lng);
    return angA - angB;
  });
}

export function computePolygonArea(points: GeoPoint[]): number {
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    area += points[i].lng * points[j].lat;
    area -= points[j].lng * points[i].lat;
  }
  return Math.abs(area) / 2;
}

export function computeBoundingBox(points: GeoPoint[]) {
  let minLat = Infinity;
  let maxLat = -Infinity;
  let minLng = Infinity;
  let maxLng = -Infinity;
  for (const p of points) {
    if (p.lat < minLat) minLat = p.lat;
    if (p.lat > maxLat) maxLat = p.lat;
    if (p.lng < minLng) minLng = p.lng;
    if (p.lng > maxLng) maxLng = p.lng;
  }
  return { minLat, maxLat, minLng, maxLng };
}

export function buildGeoZone(name: string, rawPoints: GeoPoint[]): GeoZone {
  const ordered = sortPolygonVertices(rawPoints);
  return {
    id: `zone_${name.trim()}`,
    name: name.trim(),
    points: ordered,
    bbox: computeBoundingBox(ordered),
    area: computePolygonArea(ordered),
  };
}

export function parseZonesText(text: string, existing: GeoZone[] = []): {
  zones: GeoZone[];
  added: number;
  updated: number;
  errors: string[];
} {
  const blocks = text
    .replace(/\r\n/g, '\n')
    .split(/\n\s*\n+/)
    .map((b) => b.trim())
    .filter(Boolean);

  const map = new Map<string, GeoZone>();
  for (const z of existing) {
    map.set(z.name.trim(), z);
  }

  let added = 0;
  let updated = 0;
  const errors: string[] = [];

  for (const block of blocks) {
    const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
    if (lines.length < 5) {
      errors.push(`منطقة غير مكتملة (${lines[0] ?? 'بدون اسم'}): يلزم اسم + 4 إحداثيات`);
      continue;
    }

    const name = lines[0];
    const points: GeoPoint[] = [];
    for (let i = 1; i < lines.length && points.length < 4; i++) {
      const m = lines[i].match(/(-?\d+(?:\.\d+)?)\s*[,،\s]\s*(-?\d+(?:\.\d+)?)/);
      if (m) {
        const lat = parseFloat(m[1]);
        const lng = parseFloat(m[2]);
        if (Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
          points.push({ lat, lng });
        }
      }
    }

    if (points.length !== 4) {
      errors.push(`تعذر قراءة 4 إحداثيات للمنطقة "${name}"`);
      continue;
    }

    const existed = map.has(name);
    map.set(name, buildGeoZone(name, points));
    if (existed) updated++;
    else added++;
  }

  return {
    zones: Array.from(map.values()),
    added,
    updated,
    errors,
  };
}

export function isPointInPolygon(lat: number, lng: number, polygon: GeoPoint[]): boolean {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].lng;
    const yi = polygon[i].lat;
    const xj = polygon[j].lng;
    const yj = polygon[j].lat;

    const intersect =
      yi > lat !== yj > lat &&
      lng < ((xj - xi) * (lat - yi)) / (yj - yi + 1e-18) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

export function findMatchingZone(lat: number, lng: number, zones: GeoZone[]): GeoZone | null {
  let best: GeoZone | null = null;
  for (const zone of zones) {
    if (
      lat < zone.bbox.minLat ||
      lat > zone.bbox.maxLat ||
      lng < zone.bbox.minLng ||
      lng > zone.bbox.maxLng
    ) {
      continue;
    }
    if (isPointInPolygon(lat, lng, zone.points)) {
      if (!best || zone.area < best.area) {
        best = zone;
      }
    }
  }
  return best;
}

export function roundCoordKey(lat: number, lng: number): string {
  return `${lat.toFixed(3)},${lng.toFixed(3)}`;
}

export function buildGoogleMapsUrl(lat: number, lng: number): string {
  return `https://maps.google.com/?q=${lat.toFixed(6)},${lng.toFixed(6)}`;
}

export interface NeighborhoodCacheEntry {
  name: string;
  source: 'osm' | 'bdc';
  updatedAt: number;
}

export async function reverseGeocodeNeighborhood(
  lat: number,
  lng: number
): Promise<{ name: string; source: 'osm' | 'bdc' } | null> {
  // Primary: OpenStreetMap Nominatim
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=16&accept-language=ar`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json' },
    });
    if (res.ok) {
      const data = await res.json();
      const addr = data?.address ?? {};
      const name =
        addr.neighbourhood ||
        addr.suburb ||
        addr.quarter ||
        addr.city_district ||
        addr.district ||
        addr.town ||
        addr.village ||
        addr.city ||
        data?.name;
      if (name && typeof name === 'string') {
        return { name: name.trim(), source: 'osm' };
      }
    }
  } catch {
    // Fall through to BigDataCloud
  }

  // Fallback: BigDataCloud
  try {
    const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=ar`;
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      const name = data?.locality || data?.city || data?.principalSubdivision;
      if (name && typeof name === 'string') {
        return { name: name.trim(), source: 'bdc' };
      }
    }
  } catch {
    // Offline or network blocked
  }

  return null;
}

export class GeoLookupQueue {
  private lastRequestAt = 0;
  private cache: Map<string, NeighborhoodCacheEntry>;
  private saveCacheFn: (obj: Record<string, NeighborhoodCacheEntry>) => void;
  private inFlight = new Set<string>();

  constructor(
    initialCache: Record<string, NeighborhoodCacheEntry>,
    saveCacheFn: (obj: Record<string, NeighborhoodCacheEntry>) => void
  ) {
    this.cache = new Map(Object.entries(initialCache));
    this.saveCacheFn = saveCacheFn;
  }

  public getCached(lat: number, lng: number): NeighborhoodCacheEntry | null {
    return this.cache.get(roundCoordKey(lat, lng)) ?? null;
  }

  public async resolve(lat: number, lng: number): Promise<{ name: string; source: 'osm' | 'bdc' } | null> {
    const key = roundCoordKey(lat, lng);
    const cached = this.cache.get(key);
    if (cached) return { name: cached.name, source: cached.source };

    if (this.inFlight.has(key)) return null;
    this.inFlight.add(key);

    try {
      const elapsed = Date.now() - this.lastRequestAt;
      if (elapsed < 1050) {
        await new Promise((r) => setTimeout(r, 1050 - elapsed));
      }
      this.lastRequestAt = Date.now();
      const result = await reverseGeocodeNeighborhood(lat, lng);
      if (result) {
        this.cache.set(key, {
          name: result.name,
          source: result.source,
          updatedAt: Date.now(),
        });
        this.saveCacheFn(Object.fromEntries(this.cache.entries()));
      }
      return result;
    } finally {
      this.inFlight.delete(key);
    }
  }
}
