export interface CloseableWebSocket {
  readyState: number;
  close: (code?: number, reason?: string) => void;
  terminate?: () => void;
}

const WS_CONNECTING = 0;
const WS_OPEN = 1;
const MAX_CLOSE_REASON_BYTES = 123;
const textEncoder = new TextEncoder();

/**
 * Checks whether a status code is permitted in a WebSocket close frame
 * according to RFC 6455 and the `ws` library's `isValidStatusCode`.
 */
export function isValidWsCloseCode(code: unknown): code is number {
  if (typeof code !== 'number' || !Number.isInteger(code)) {
    return false;
  }
  return (
    (code >= 1000 &&
      code <= 1014 &&
      code !== 1004 &&
      code !== 1005 &&
      code !== 1006) ||
    (code >= 3000 && code <= 4999)
  );
}

/**
 * Returns a valid WebSocket close status code, replacing non-transmittable codes
 * such as 1005, 1006, 1015, or invalid values with a valid fallback.
 */
export function sanitizeCloseCode(rawCode: unknown, fallback = 1000): number {
  if (isValidWsCloseCode(rawCode)) {
    return rawCode;
  }
  return isValidWsCloseCode(fallback) ? fallback : 1000;
}

/**
 * Truncates a close reason string so its UTF-8 encoding does not exceed 123 bytes
 * without splitting multi-byte UTF-8 characters or UTF-16 surrogate pairs.
 */
export function truncateCloseReason(
  rawReason: unknown,
  maxBytes = MAX_CLOSE_REASON_BYTES
): string {
  if (typeof rawReason !== 'string' || rawReason.length === 0 || maxBytes <= 0) {
    return '';
  }
  if (textEncoder.encode(rawReason).length <= maxBytes) {
    return rawReason;
  }
  let out = '';
  let byteCount = 0;
  for (const ch of rawReason) {
    const chBytes = textEncoder.encode(ch).length;
    if (byteCount + chBytes > maxBytes) {
      break;
    }
    out += ch;
    byteCount += chBytes;
  }
  return out;
}

/**
 * Safely closes a WebSocket without throwing `TypeError` on invalid close codes
 * (e.g., 1005/1006/1015) or `RangeError` on close reasons exceeding 123 UTF-8 bytes.
 */
export function safeCloseWebSocket(
  ws: CloseableWebSocket,
  rawCode?: unknown,
  rawReason?: unknown,
  fallbackCode = 1000
): void {
  if (ws.readyState === WS_CONNECTING) {
    try {
      ws.terminate?.();
    } catch {
      // Ignore termination errors while connecting
    }
    return;
  }

  if (ws.readyState !== WS_OPEN) {
    return;
  }

  const code = sanitizeCloseCode(rawCode, fallbackCode);
  const reason = truncateCloseReason(rawReason, MAX_CLOSE_REASON_BYTES);

  try {
    if (reason) {
      ws.close(code, reason);
    } else {
      ws.close(code);
    }
  } catch {
    try {
      ws.terminate?.();
    } catch {
      // Ignore fallback termination errors
    }
  }
}

export function extractErrorMessage(err: unknown, fallback: string): string {
  if (err instanceof Error && err.message.trim()) {
    return err.message.trim();
  }
  if (err && typeof err === 'object') {
    const record = err as { message?: unknown; error?: unknown; reason?: unknown };
    if (typeof record.message === 'string' && record.message.trim()) {
      return record.message.trim();
    }
    if (record.error instanceof Error && record.error.message.trim()) {
      return record.error.message.trim();
    }
    if (typeof record.reason === 'string' && record.reason.trim()) {
      return record.reason.trim();
    }
  }
  return fallback;
}
