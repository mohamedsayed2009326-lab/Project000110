import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isValidWsCloseCode,
  sanitizeCloseCode,
  truncateCloseReason,
  safeCloseWebSocket,
  extractErrorMessage,
} from './wsUtils';

test('isValidWsCloseCode rejects 1004, 1005, 1006, 1015 and out-of-range codes', () => {
  assert.equal(isValidWsCloseCode(1000), true);
  assert.equal(isValidWsCloseCode(1001), true);
  assert.equal(isValidWsCloseCode(1011), true);
  assert.equal(isValidWsCloseCode(3000), true);
  assert.equal(isValidWsCloseCode(4999), true);

  assert.equal(isValidWsCloseCode(1004), false);
  assert.equal(isValidWsCloseCode(1005), false);
  assert.equal(isValidWsCloseCode(1006), false);
  assert.equal(isValidWsCloseCode(1015), false);
  assert.equal(isValidWsCloseCode(999), false);
  assert.equal(isValidWsCloseCode(5000), false);
  assert.equal(isValidWsCloseCode(NaN), false);
  assert.equal(isValidWsCloseCode(undefined), false);
  assert.equal(isValidWsCloseCode(1000.5), false);
});

test('sanitizeCloseCode maps invalid codes to valid fallback', () => {
  assert.equal(sanitizeCloseCode(1006, 1000), 1000);
  assert.equal(sanitizeCloseCode(1005, 1011), 1011);
  assert.equal(sanitizeCloseCode(1015, 1011), 1011);
  assert.equal(sanitizeCloseCode(undefined, 1000), 1000);
  assert.equal(sanitizeCloseCode(1001, 1000), 1001);
  assert.equal(sanitizeCloseCode(4001, 1000), 4001);
});

test('truncateCloseReason stays within 123 UTF-8 bytes including multi-byte Arabic text', () => {
  const arabic = 'تعذر الاتصال بخدمة التفريغ الصوتي '.repeat(10);
  const truncated = truncateCloseReason(arabic, 123);
  const bytes = new TextEncoder().encode(truncated).length;
  assert.ok(bytes <= 123);
  assert.ok(bytes > 100);
  assert.equal(truncated.includes('\uFFFD'), false);
});

test('safeCloseWebSocket sanitizes 1005/1006/1015 and long reasons when OPEN', () => {
  const calls: Array<{ code?: number; reason?: string }> = [];
  const fakeWs = {
    readyState: 1, // OPEN
    close: (code?: number, reason?: string) => {
      if (code !== undefined && !isValidWsCloseCode(code)) {
        throw new TypeError('First argument must be a valid error code number');
      }
      if (reason && new TextEncoder().encode(reason).length > 123) {
        throw new RangeError('Reason too long');
      }
      calls.push({ code, reason });
    },
  };

  safeCloseWebSocket(fakeWs, 1006, 'A'.repeat(200), 1011);
  safeCloseWebSocket(fakeWs, 1005, 'Live session closed', 1000);
  safeCloseWebSocket(fakeWs, 1015, undefined, 1011);

  assert.equal(calls.length, 3);
  assert.equal(calls[0].code, 1011);
  assert.equal(calls[0].reason?.length, 123);
  assert.equal(calls[1].code, 1000);
  assert.equal(calls[1].reason, 'Live session closed');
  assert.equal(calls[2].code, 1011);
});

test('safeCloseWebSocket terminates CONNECTING socket instead of throwing on close()', () => {
  let terminated = false;
  let closed = false;
  safeCloseWebSocket(
    {
      readyState: 0, // CONNECTING
      close: () => {
        closed = true;
      },
      terminate: () => {
        terminated = true;
      },
    },
    1006,
    'err'
  );
  assert.equal(terminated, true);
  assert.equal(closed, false);
});

test('extractErrorMessage handles Error, WebSocket ErrorEvent-like objects, and fallbacks', () => {
  assert.equal(extractErrorMessage(new Error('boom'), 'fb'), 'boom');
  assert.equal(extractErrorMessage({ message: 'ws err' }, 'fb'), 'ws err');
  assert.equal(
    extractErrorMessage({ error: new Error('nested err') }, 'fb'),
    'nested err'
  );
  assert.equal(extractErrorMessage(null, 'fb'), 'fb');
});
