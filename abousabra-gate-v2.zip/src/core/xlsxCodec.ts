import { normalizePlateText, splitPlateParts } from './plateParser';
import { buildGeoZone, buildGoogleMapsUrl } from './geoZones';
import type { PlateRecord, WatchlistEntry } from './types';

// Keep buildGeoZone unused warning clean if not needed
void buildGeoZone;

// ---------------------------------------------------------------------------
// CRC-32 for ZIP writer
// ---------------------------------------------------------------------------
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function xmlEscape(str: string): string {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function xmlUnescape(str: string): string {
  return str
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
}

function colIndexToLetter(idx: number): string {
  let n = idx + 1;
  let out = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    out = String.fromCharCode(65 + rem) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

function colLettersToIndex(letters: string): number {
  let idx = 0;
  for (let i = 0; i < letters.length; i++) {
    idx = idx * 26 + (letters.charCodeAt(i) - 64);
  }
  return idx - 1;
}

// ---------------------------------------------------------------------------
// Zero-library Stored ZIP Writer + RTL XLSX Exporter
// ---------------------------------------------------------------------------
interface ZipEntryInput {
  name: string;
  data: Uint8Array;
}

export function buildStoredZip(entries: ZipEntryInput[]): Uint8Array {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name);
    const data = entry.data;
    const crc = crc32(data);

    // Local file header (30 bytes + name)
    const lh = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true); // UTF-8
    lv.setUint16(8, 0, true); // STORE (uncompressed)
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, data.length, true);
    lv.setUint32(22, data.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    lh.set(nameBytes, 30);

    localParts.push(lh, data);

    // Central directory header (46 bytes + name)
    const ch = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    ch.set(nameBytes, 46);

    centralParts.push(ch);
    offset += lh.length + data.length;
  }

  const centralSize = centralParts.reduce((s, p) => s + p.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralSize + eocd.length;
  const out = new Uint8Array(totalSize);
  let pos = 0;
  for (const part of localParts) {
    out.set(part, pos);
    pos += part.length;
  }
  for (const part of centralParts) {
    out.set(part, pos);
    pos += part.length;
  }
  out.set(eocd, pos);
  return out;
}

function statusArabicLabel(status: PlateRecord['status']): string {
  if (status === 'wanted') return 'مطلوبة';
  if (status === 'invalid') return 'خطأ';
  return 'سليمة';
}

function formatExcelTimestamp(ts: number): string {
  const d = new Date(ts);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function exportRecordsToXlsx(records: PlateRecord[]): Uint8Array {
  const enc = new TextEncoder();

  const headers = [
    '#',
    'اللوحة',
    'النوع',
    'الحالة',
    'الوقت',
    'الموقع (الحي)',
    'الإحداثيات',
    'بيانات المطلوب',
  ];

  const rowsXml: string[] = [];

  // Header row (row 1)
  const headerCells = headers
    .map((h, cIdx) => {
      const ref = `${colIndexToLetter(cIdx)}1`;
      return `<c r="${ref}" t="inlineStr" s="1"><is><t>${xmlEscape(h)}</t></is></c>`;
    })
    .join('');
  rowsXml.push(`<row r="1">${headerCells}</row>`);

  // Data rows
  records.forEach((rec, i) => {
    const rNum = i + 2;
    const coords =
      rec.lat !== undefined && rec.lng !== undefined
        ? `${rec.lat.toFixed(6)}, ${rec.lng.toFixed(6)}`
        : '';
    const locLabel = rec.locationName || (coords ? 'الموقع على الخريطة' : '');
    const mapUrl =
      rec.lat !== undefined && rec.lng !== undefined
        ? buildGoogleMapsUrl(rec.lat, rec.lng)
        : '';

    const statusStyle = rec.status === 'wanted' ? '3' : rec.status === 'invalid' ? '4' : '0';

    const c0 = `<c r="A${rNum}" t="n"><v>${i + 1}</v></c>`;
    const c1 = `<c r="B${rNum}" t="inlineStr"><is><t>${xmlEscape(rec.plate)}</t></is></c>`;
    const c2 = `<c r="C${rNum}" t="inlineStr"><is><t>${xmlEscape(rec.vehicleType || '')}</t></is></c>`;
    const c3 = `<c r="D${rNum}" t="inlineStr" s="${statusStyle}"><is><t>${xmlEscape(statusArabicLabel(rec.status))}</t></is></c>`;
    const c4 = `<c r="E${rNum}" t="inlineStr"><is><t>${xmlEscape(formatExcelTimestamp(rec.timestamp))}</t></is></c>`;

    let c5: string;
    if (mapUrl && mapUrl.length <= 250 && locLabel) {
      const safeLabel = locLabel.replace(/"/g, '""');
      const formula = `HYPERLINK("${mapUrl}","${safeLabel}")`;
      c5 = `<c r="F${rNum}" t="str" s="2"><f>${xmlEscape(formula)}</f><v>${xmlEscape(locLabel)}</v></c>`;
    } else {
      c5 = `<c r="F${rNum}" t="inlineStr"><is><t>${xmlEscape(locLabel)}</t></is></c>`;
    }

    const c6 = `<c r="G${rNum}" t="inlineStr"><is><t>${xmlEscape(coords)}</t></is></c>`;
    const c7 = `<c r="H${rNum}" t="inlineStr"><is><t>${xmlEscape(rec.wantedData?.rawSummary || '')}</t></is></c>`;

    rowsXml.push(`<row r="${rNum}">${c0}${c1}${c2}${c3}${c4}${c5}${c6}${c7}</row>`);
  });

  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews>
    <sheetView workbookViewId="0" rightToLeft="1"/>
  </sheetViews>
  <cols>
    <col min="1" max="1" width="7" customWidth="1"/>
    <col min="2" max="2" width="16" customWidth="1"/>
    <col min="3" max="3" width="14" customWidth="1"/>
    <col min="4" max="4" width="12" customWidth="1"/>
    <col min="5" max="5" width="22" customWidth="1"/>
    <col min="6" max="6" width="26" customWidth="1"/>
    <col min="7" max="7" width="24" customWidth="1"/>
    <col min="8" max="8" width="42" customWidth="1"/>
  </cols>
  <sheetData>
    ${rowsXml.join('\n    ')}
  </sheetData>
</worksheet>`;

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;

  const rootRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

  const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="التشييك الصوتي" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`;

  const workbookRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="5">
    <font><sz val="11"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
    <font><u/><sz val="11"/><color rgb="FF0563C1"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FF854D0E"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FF991B1B"/><name val="Arial"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF0F3D2E"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFEF08A"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFEE2E2"/></patternFill></fill>
  </fills>
  <borders count="1">
    <border><left/><right/><top/><bottom/><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="5">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="0" fontId="3" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="0" fontId="4" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
  </cellXfs>
</styleSheet>`;

  return buildStoredZip([
    { name: '[Content_Types].xml', data: enc.encode(contentTypesXml) },
    { name: '_rels/.rels', data: enc.encode(rootRelsXml) },
    { name: 'xl/workbook.xml', data: enc.encode(workbookXml) },
    { name: 'xl/_rels/workbook.xml.rels', data: enc.encode(workbookRelsXml) },
    { name: 'xl/styles.xml', data: enc.encode(stylesXml) },
    { name: 'xl/worksheets/sheet1.xml', data: enc.encode(sheetXml) },
  ]);
}

// ---------------------------------------------------------------------------
// Zero-library Streaming XLSX + CSV Reader (Central Directory + DecompressionStream)
// ---------------------------------------------------------------------------
interface ZipCentralEntry {
  name: string;
  method: number;
  compressedSize: number;
  uncompressedSize: number;
  localHeaderOffset: number;
}

async function readBlobSlice(blob: Blob, start: number, end: number): Promise<Uint8Array> {
  const buf = await blob.slice(start, end).arrayBuffer();
  return new Uint8Array(buf);
}

async function parseZipCentralDirectory(blob: Blob): Promise<Map<string, ZipCentralEntry>> {
  const size = blob.size;
  const tailLen = Math.min(size, 65557);
  const tail = await readBlobSlice(blob, size - tailLen, size);

  let eocdOffset = -1;
  for (let i = tail.length - 22; i >= 0; i--) {
    if (
      tail[i] === 0x50 &&
      tail[i + 1] === 0x4b &&
      tail[i + 2] === 0x05 &&
      tail[i + 3] === 0x06
    ) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset === -1) {
    throw new Error('الملف ليس ملف إكسل (xlsx) صالحاً');
  }

  const eocdView = new DataView(tail.buffer, tail.byteOffset + eocdOffset, 22);
  const cdSize = eocdView.getUint32(12, true);
  const cdOffset = eocdView.getUint32(16, true);

  const cdBytes = await readBlobSlice(blob, cdOffset, cdOffset + cdSize);
  const cdView = new DataView(cdBytes.buffer, cdBytes.byteOffset, cdBytes.byteLength);
  const dec = new TextDecoder('utf-8');
  const map = new Map<string, ZipCentralEntry>();

  let pos = 0;
  while (pos + 46 <= cdBytes.length) {
    if (cdView.getUint32(pos, true) !== 0x02014b50) break;
    const method = cdView.getUint16(pos + 10, true);
    const compressedSize = cdView.getUint32(pos + 20, true);
    const uncompressedSize = cdView.getUint32(pos + 24, true);
    const nameLen = cdView.getUint16(pos + 28, true);
    const extraLen = cdView.getUint16(pos + 30, true);
    const commentLen = cdView.getUint16(pos + 32, true);
    const localHeaderOffset = cdView.getUint32(pos + 42, true);

    const name = dec.decode(cdBytes.subarray(pos + 46, pos + 46 + nameLen));
    map.set(name, {
      name,
      method,
      compressedSize,
      uncompressedSize,
      localHeaderOffset,
    });
    pos += 46 + nameLen + extraLen + commentLen;
  }

  return map;
}

async function openZipEntryStream(
  blob: Blob,
  entry: ZipCentralEntry
): Promise<ReadableStream<Uint8Array>> {
  const lh = await readBlobSlice(blob, entry.localHeaderOffset, entry.localHeaderOffset + 30);
  const lv = new DataView(lh.buffer, lh.byteOffset, 30);
  const nameLen = lv.getUint16(26, true);
  const extraLen = lv.getUint16(28, true);
  const dataStart = entry.localHeaderOffset + 30 + nameLen + extraLen;
  const compressedBlob = blob.slice(dataStart, dataStart + entry.compressedSize);

  const rawStream = compressedBlob.stream() as ReadableStream<Uint8Array>;
  if (entry.method === 0) {
    return rawStream;
  }
  if (entry.method === 8) {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('المتصفح لا يدعم DecompressionStream لفك ضغط الإكسل');
    }
    return rawStream.pipeThrough(
      new DecompressionStream('deflate-raw') as unknown as TransformStream<Uint8Array, Uint8Array>
    );
  }
  throw new Error(`طريقة ضغط غير مدعومة في ملف الإكسل (${entry.method})`);
}

async function streamXmlLinesOrTags(
  stream: ReadableStream<Uint8Array>,
  tagEndMarker: string,
  onTagBlock: (block: string) => Promise<void> | void
): Promise<void> {
  const reader = stream.getReader();
  const dec = new TextDecoder('utf-8');
  let buffer = '';
  let blocksSinceYield = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (value) {
      buffer += dec.decode(value, { stream: !done });
    }
    if (done) {
      buffer += dec.decode();
    }

    let idx = buffer.indexOf(tagEndMarker);
    while (idx !== -1) {
      const endPos = idx + tagEndMarker.length;
      const chunk = buffer.slice(0, endPos);
      buffer = buffer.slice(endPos);
      await onTagBlock(chunk);
      blocksSinceYield++;
      if (blocksSinceYield >= 1500) {
        blocksSinceYield = 0;
        await new Promise((r) => setTimeout(r, 0));
      }
      idx = buffer.indexOf(tagEndMarker);
    }

    if (done) {
      if (buffer.trim()) {
        await onTagBlock(buffer);
      }
      break;
    }
  }
}

async function loadSharedStrings(
  blob: Blob,
  entry: ZipCentralEntry | undefined
): Promise<string[]> {
  if (!entry) return [];
  const strings: string[] = [];
  const stream = await openZipEntryStream(blob, entry);
  await streamXmlLinesOrTags(stream, '</si>', (chunk) => {
    const siStart = chunk.lastIndexOf('<si');
    if (siStart === -1) return;
    const siBody = chunk.slice(siStart);
    let combined = '';
    const tRegex = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;
    let m: RegExpExecArray | null;
    while ((m = tRegex.exec(siBody)) !== null) {
      combined += xmlUnescape(m[1]);
    }
    strings.push(combined);
  });
  return strings;
}

function parseSheetRowBlock(rowChunk: string, sharedStrings: string[]): string[] {
  const rowStart = rowChunk.lastIndexOf('<row');
  if (rowStart === -1) return [];
  const rowXml = rowChunk.slice(rowStart);
  const cells: string[] = [];

  const cellRegex = /<c\b([^>]*)>([\s\S]*?)<\/c>|<c\b([^>]*)\/>/g;
  let cm: RegExpExecArray | null;
  let sequentialCol = 0;

  while ((cm = cellRegex.exec(rowXml)) !== null) {
    const attrs = cm[1] ?? cm[3] ?? '';
    const inner = cm[2] ?? '';

    const refMatch = attrs.match(/\br="([A-Z]+)\d+"/);
    const colIdx = refMatch ? colLettersToIndex(refMatch[1]) : sequentialCol;
    sequentialCol = colIdx + 1;

    const typeMatch = attrs.match(/\bt="([^"]+)"/);
    const cellType = typeMatch ? typeMatch[1] : '';

    let val = '';
    if (cellType === 'inlineStr') {
      const tMatches = inner.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g);
      for (const tm of tMatches) {
        val += xmlUnescape(tm[1]);
      }
    } else {
      const vMatch = inner.match(/<v>([\s\S]*?)<\/v>/);
      if (vMatch) {
        const rawV = xmlUnescape(vMatch[1]);
        if (cellType === 's') {
          const sIdx = Number(rawV);
          val = sharedStrings[sIdx] ?? '';
        } else {
          val = rawV;
        }
      }
    }

    while (cells.length <= colIdx) cells.push('');
    cells[colIdx] = val.trim();
  }

  return cells;
}

export function looksLikePlateCell(raw: string): boolean {
  if (!raw) return false;
  const norm = normalizePlateText(raw);
  if (!norm) return false;
  const { letters, digits } = splitPlateParts(norm);
  return letters.length >= 2 && letters.length <= 4 && digits.length >= 3 && digits.length <= 4;
}

export function detectPlateColumn(rows: string[][]): {
  colIndex: number | null;
  headerRowIndex: number;
  headers: string[];
  samples: string[][];
} {
  if (rows.length === 0) {
    return { colIndex: null, headerRowIndex: 0, headers: [], samples: [] };
  }

  // Find likely header row (first row with >= 2 non-empty columns or containing "لوح" / "plate")
  let headerRowIndex = 0;
  for (let r = 0; r < Math.min(rows.length, 10); r++) {
    const row = rows[r];
    const nonEmpty = row.filter((c) => c.trim().length > 0);
    const hasPlateHeader = row.some((c) => /لوح|plate/i.test(c));
    if (hasPlateHeader || nonEmpty.length >= 2) {
      headerRowIndex = r;
      break;
    }
  }

  const headers = rows[headerRowIndex] ?? [];
  const dataRows = rows.slice(headerRowIndex + 1).filter((r) => r.some((c) => c.trim() !== ''));
  const samples = dataRows.slice(0, 5);

  // 1. Check by column header name
  for (let c = 0; c < headers.length; c++) {
    if (/لوح|plate/i.test(headers[c])) {
      return { colIndex: c, headerRowIndex, headers, samples };
    }
  }

  // 2. Check by content (>50% matching 2-4 letters + 3-4 digits)
  const sampleCheck = dataRows.slice(0, 100);
  if (sampleCheck.length > 0) {
    const maxCols = Math.max(headers.length, ...sampleCheck.map((r) => r.length));
    let bestCol = -1;
    let bestRatio = 0;
    for (let c = 0; c < maxCols; c++) {
      let nonEmpty = 0;
      let plateHits = 0;
      for (const r of sampleCheck) {
        const cell = (r[c] ?? '').trim();
        if (!cell) continue;
        nonEmpty++;
        if (looksLikePlateCell(cell)) plateHits++;
      }
      if (nonEmpty >= 1) {
        const ratio = plateHits / nonEmpty;
        if (ratio > 0.5 && ratio > bestRatio) {
          bestRatio = ratio;
          bestCol = c;
        }
      }
    }
    if (bestCol !== -1) {
      return { colIndex: bestCol, headerRowIndex, headers, samples };
    }
  }

  return { colIndex: null, headerRowIndex, headers, samples };
}

function rowToWatchlistEntry(
  row: string[],
  plateCol: number,
  headers: string[]
): WatchlistEntry | null {
  const rawPlate = row[plateCol] ?? '';
  if (!looksLikePlateCell(rawPlate)) return null;
  const plate = normalizePlateText(rawPlate);
  if (!plate) return null;

  const extra: Record<string, string> = {};
  let type = '';
  let bank = '';
  let chassis = '';
  let certificate = '';
  const summaryParts: string[] = [];

  for (let c = 0; c < row.length; c++) {
    if (c === plateCol) continue;
    const val = (row[c] ?? '').trim();
    if (!val) continue;
    const h = (headers[c] ?? `عمود ${c + 1}`).trim();
    extra[h] = val;

    if (/نوع|type/i.test(h)) type = val;
    else if (/بنك|bank|جهة/i.test(h)) bank = val;
    else if (/شاص|شاسيه|chassis/i.test(h)) chassis = val;
    else if (/شهاد|رقم|cert/i.test(h)) certificate = val;

    summaryParts.push(`${h}: ${val}`);
  }

  return {
    plate,
    type: type || undefined,
    bank: bank || undefined,
    chassis: chassis || undefined,
    certificate: certificate || undefined,
    extra,
    rawSummary: summaryParts.join(' | ') || 'مسجلة في ملف المطابقة',
  };
}

export interface WatchlistParseResult {
  needsColumnSelection?: {
    headers: string[];
    samples: string[][];
  };
  totalRowsScanned: number;
  importedCount: number;
}

function parseCsvLine(line: string, delimiter: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === delimiter && !inQuotes) {
      out.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur.trim());
  return out;
}

export async function streamImportWatchlistFile(
  file: Blob,
  fileName: string,
  options: {
    forcedPlateCol?: number;
    onBatch: (entries: WatchlistEntry[]) => Promise<void>;
    onProgress?: (rowsScanned: number, importedCount: number) => void;
  }
): Promise<WatchlistParseResult> {
  const isCsv = /\.csv$/i.test(fileName) || file.type === 'text/csv';

  if (isCsv) {
    const reader = (file.stream() as ReadableStream<Uint8Array>).getReader();
    const dec = new TextDecoder('utf-8');
    let leftover = '';
    let delimiter = ',';
    const previewRows: string[][] = [];
    let resolvedCol: number | undefined = options.forcedPlateCol;
    let headerRowIndex = 0;
    let headers: string[] = [];
    let rowsScanned = 0;
    let importedCount = 0;
    let batch: WatchlistEntry[] = [];
    let initialized = false;

    const processRow = async (cells: string[]) => {
      rowsScanned++;
      if (!initialized) {
        previewRows.push(cells);
        if (previewRows.length >= 25) {
          const detected = detectPlateColumn(previewRows);
          headerRowIndex = detected.headerRowIndex;
          headers = detected.headers;
          if (resolvedCol === undefined) {
            if (detected.colIndex === null) {
              throw { __needsColumnSelection: true, headers, samples: detected.samples };
            }
            resolvedCol = detected.colIndex;
          }
          initialized = true;
          for (let i = headerRowIndex + 1; i < previewRows.length; i++) {
            const entry = rowToWatchlistEntry(previewRows[i], resolvedCol, headers);
            if (entry) batch.push(entry);
          }
        }
        return;
      }
      if (resolvedCol !== undefined) {
        const entry = rowToWatchlistEntry(cells, resolvedCol, headers);
        if (entry) {
          batch.push(entry);
          if (batch.length >= 2000) {
            importedCount += batch.length;
            await options.onBatch(batch);
            batch = [];
            options.onProgress?.(rowsScanned, importedCount);
          }
        }
      }
    };

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (value) leftover += dec.decode(value, { stream: !done });
        if (done) leftover += dec.decode();

        const lines = leftover.split(/\r?\n/);
        leftover = done ? '' : (lines.pop() ?? '');

        for (const line of lines) {
          if (!line.trim()) continue;
          if (rowsScanned === 0) {
            const cleanFirst = line.replace(/^\uFEFF/, '');
            if (cleanFirst.includes(';') && !cleanFirst.includes(',')) delimiter = ';';
            else if (cleanFirst.includes('\t') && !cleanFirst.includes(',')) delimiter = '\t';
            await processRow(parseCsvLine(cleanFirst, delimiter));
          } else {
            await processRow(parseCsvLine(line, delimiter));
          }
        }
        if (done) break;
      }

      if (!initialized && previewRows.length > 0) {
        const detected = detectPlateColumn(previewRows);
        headerRowIndex = detected.headerRowIndex;
        headers = detected.headers;
        if (resolvedCol === undefined) {
          if (detected.colIndex === null) {
            return {
              needsColumnSelection: { headers, samples: detected.samples },
              totalRowsScanned: rowsScanned,
              importedCount: 0,
            };
          }
          resolvedCol = detected.colIndex;
        }
        for (let i = headerRowIndex + 1; i < previewRows.length; i++) {
          const entry = rowToWatchlistEntry(previewRows[i], resolvedCol, headers);
          if (entry) batch.push(entry);
        }
      }

      if (batch.length > 0) {
        importedCount += batch.length;
        await options.onBatch(batch);
      }
      options.onProgress?.(rowsScanned, importedCount);
      return { totalRowsScanned: rowsScanned, importedCount };
    } catch (err: unknown) {
      if (err && typeof err === 'object' && '__needsColumnSelection' in err) {
        const info = err as unknown as { headers: string[]; samples: string[][] };
        await reader.cancel();
        return {
          needsColumnSelection: { headers: info.headers, samples: info.samples },
          totalRowsScanned: rowsScanned,
          importedCount: 0,
        };
      }
      throw err;
    }
  }

  // XLSX path
  const cd = await parseZipCentralDirectory(file);
  const sharedStrings = await loadSharedStrings(file, cd.get('xl/sharedStrings.xml'));

  // Find worksheet entry (sheet1.xml or first sheet in xl/worksheets/)
  let sheetEntry = cd.get('xl/worksheets/sheet1.xml');
  if (!sheetEntry) {
    for (const [name, entry] of cd.entries()) {
      if (/^xl\/worksheets\/sheet\d+\.xml$/i.test(name)) {
        sheetEntry = entry;
        break;
      }
    }
  }
  if (!sheetEntry) {
    throw new Error('لم يتم العثور على ورقة بيانات داخل ملف الإكسل');
  }

  const sheetStream = await openZipEntryStream(file, sheetEntry);
  const previewRows: string[][] = [];
  let resolvedCol: number | undefined = options.forcedPlateCol;
  let headers: string[] = [];
  let headerRowIndex = 0;
  let rowsScanned = 0;
  let importedCount = 0;
  let batch: WatchlistEntry[] = [];
  let initialized = false;
  let abortNeedsCol: { headers: string[]; samples: string[][] } | null = null;

  try {
    await streamXmlLinesOrTags(sheetStream, '</row>', async (rowChunk) => {
      if (abortNeedsCol) return;
      const cells = parseSheetRowBlock(rowChunk, sharedStrings);
      if (cells.length === 0 || !cells.some((c) => c.trim() !== '')) return;
      rowsScanned++;

      if (!initialized) {
        previewRows.push(cells);
        if (previewRows.length >= 25) {
          const detected = detectPlateColumn(previewRows);
          headerRowIndex = detected.headerRowIndex;
          headers = detected.headers;
          if (resolvedCol === undefined) {
            if (detected.colIndex === null) {
              abortNeedsCol = { headers, samples: detected.samples };
              throw new Error('__ABORT_NEED_COL__');
            }
            resolvedCol = detected.colIndex;
          }
          initialized = true;
          for (let i = headerRowIndex + 1; i < previewRows.length; i++) {
            const entry = rowToWatchlistEntry(previewRows[i], resolvedCol, headers);
            if (entry) batch.push(entry);
          }
        }
        return;
      }

      if (resolvedCol !== undefined) {
        const entry = rowToWatchlistEntry(cells, resolvedCol, headers);
        if (entry) {
          batch.push(entry);
          if (batch.length >= 2000) {
            importedCount += batch.length;
            await options.onBatch(batch);
            batch = [];
            options.onProgress?.(rowsScanned, importedCount);
          }
        }
      }
    });
  } catch (err) {
    if (abortNeedsCol) {
      return {
        needsColumnSelection: abortNeedsCol,
        totalRowsScanned: rowsScanned,
        importedCount: 0,
      };
    }
    throw err;
  }

  if (!initialized && previewRows.length > 0) {
    const detected = detectPlateColumn(previewRows);
    headerRowIndex = detected.headerRowIndex;
    headers = detected.headers;
    if (resolvedCol === undefined) {
      if (detected.colIndex === null) {
        return {
          needsColumnSelection: { headers, samples: detected.samples },
          totalRowsScanned: rowsScanned,
          importedCount: 0,
        };
      }
      resolvedCol = detected.colIndex;
    }
    for (let i = headerRowIndex + 1; i < previewRows.length; i++) {
      const entry = rowToWatchlistEntry(previewRows[i], resolvedCol, headers);
      if (entry) batch.push(entry);
    }
  }

  if (batch.length > 0) {
    importedCount += batch.length;
    await options.onBatch(batch);
  }
  options.onProgress?.(rowsScanned, importedCount);

  return { totalRowsScanned: rowsScanned, importedCount };
}

export function parsePastedPlatesText(text: string): WatchlistEntry[] {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const entries: WatchlistEntry[] = [];
  for (const line of lines) {
    const parts = line.split(/[\t,|]/).map((p) => p.trim());
    const plate = normalizePlateText(parts[0] ?? line);
    if (!plate) continue;
    const summary = parts.slice(1).filter(Boolean).join(' | ') || 'مضافة يدوياً لقائمة المطلوب';
    entries.push({
      plate,
      rawSummary: summary,
    });
  }
  return entries;
}
