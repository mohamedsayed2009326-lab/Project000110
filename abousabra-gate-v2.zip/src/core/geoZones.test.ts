import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseZonesText,
  findMatchingZone,
  roundCoordKey,
  sortPolygonVertices,
} from './geoZones';

test('parseZonesText handles butterfly vertex order and picks smallest overlapping zone', () => {
  const input = `
حي كبير
30.0000, 31.2000
30.0500, 31.2500
30.0000, 31.2500
30.0500, 31.2000

جني — الرمال
30.0100, 31.2100
30.0200, 31.2200
30.0100, 31.2200
30.0200, 31.2100
`;
  const { zones, added, errors } = parseZonesText(input, []);
  assert.equal(errors.length, 0);
  assert.equal(added, 2);

  // Inside both -> should pick smaller zone ("جني — الرمال")
  const match = findMatchingZone(30.015, 31.215, zones);
  assert.equal(match?.name, 'جني — الرمال');

  // Inside outer only
  const outer = findMatchingZone(30.04, 31.24, zones);
  assert.equal(outer?.name, 'حي كبير');

  // Outside both
  const none = findMatchingZone(31.0, 31.0, zones);
  assert.equal(none, null);
});

test('parseZonesText updates existing zone with same name', () => {
  const initial = parseZonesText(`
بوابة 1
30.0, 31.0
30.0, 31.1
30.1, 31.1
30.1, 31.0
`).zones;

  const updated = parseZonesText(
    `
بوابة 1
30.2, 31.2
30.2, 31.3
30.3, 31.3
30.3, 31.2
`,
    initial
  );

  assert.equal(updated.updated, 1);
  assert.equal(updated.added, 0);
  assert.equal(updated.zones.length, 1);
  assert.equal(findMatchingZone(30.25, 31.25, updated.zones)?.name, 'بوابة 1');
  assert.equal(findMatchingZone(30.05, 31.05, updated.zones), null);
});

test('sortPolygonVertices orders crossed quad non-self-intersecting', () => {
  const ordered = sortPolygonVertices([
    { lat: 0, lng: 0 },
    { lat: 10, lng: 10 },
    { lat: 0, lng: 10 },
    { lat: 10, lng: 0 },
  ]);
  assert.equal(ordered.length, 4);
  // Angles around (5,5): (-135deg), (-45deg), (45deg), (135deg)
  assert.deepEqual(ordered[0], { lat: 0, lng: 0 });
  assert.deepEqual(ordered[1], { lat: 0, lng: 10 });
  assert.deepEqual(ordered[2], { lat: 10, lng: 10 });
  assert.deepEqual(ordered[3], { lat: 10, lng: 0 });
});

test('roundCoordKey rounds to 3 decimal places', () => {
  assert.equal(roundCoordKey(30.123456, 31.987654), '30.123,31.988');
});
