import test from 'node:test';
import assert from 'node:assert/strict';
import {
  exportRecordsToXlsx,
  streamImportWatchlistFile,
  parsePastedPlatesText,
} from './xlsxCodec';
import type { PlateRecord } from './types';

test('Export XLSX creates valid RTL zip with HYPERLINK and round-trips through streaming reader', async () => {
  const records: PlateRecord[] = [
    {
      id: '1',
      plate: 'رحم3249',
      letters: 'رحم',
      digits: '3249',
      vehicleType: 'ملاكي',
      status: 'wanted',
      wantedData: {
        plate: 'رحم3249',
        bank: 'بنك مصر',
        rawSummary: 'النوع: ملاكي | البنك: بنك مصر',
      },
      timestamp: 1700000000000,
      lat: 30.0444,
      lng: 31.2357,
      locationName: 'جني — الرمال',
      locationSource: 'zone',
      mode: 'abousabra',
      source: 'voice',
    },
    {
      id: '2',
      plate: 'ربل0027',
      letters: 'ربل',
      digits: '0027',
      vehicleType: '',
      status: 'valid',
      timestamp: 1700000010000,
      mode: 'abousabra',
      source: 'manual',
    },
  ];

  const xlsxBytes = exportRecordsToXlsx(records);
  const text = new TextDecoder().decode(xlsxBytes);

  // Verify RTL worksheet, plate without spaces, and HYPERLINK formula
  assert.ok(text.includes('rightToLeft="1"'));
  assert.ok(text.includes('رحم3249'));
  assert.ok(text.includes('HYPERLINK(&quot;https://maps.google.com/?q=30.044400,31.235700&quot;,&quot;جني — الرمال&quot;)'));

  // Round-trip through streaming XLSX reader as a Blob
  const blob = new Blob([xlsxBytes.buffer as ArrayBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const imported: string[] = [];
  const res = await streamImportWatchlistFile(blob, 'test.xlsx', {
    onBatch: async (batch) => {
      for (const e of batch) imported.push(e.plate);
    },
  });

  assert.equal(res.needsColumnSelection, undefined);
  assert.deepEqual(imported, ['رحم3249', 'ربل0027']);
});

test('CSV import skips banner/non-plate rows and normalizes tatweel/alef/digits', async () => {
  const csv = [
    'تقرير يومي - عرض خاص,,,',
    'اللوحه,النوع,البنك,الشاص',
    'ب ح هـ ٣٢٤,ملاكي,الأهلي,CH991',
    'صف فاضي,,,',
    'أ ب ج 12,نقل,مصر,CH992',
  ].join('\n');

  const blob = new Blob([csv], { type: 'text/csv' });
  const imported: Array<{ plate: string; summary: string }> = [];
  await streamImportWatchlistFile(blob, 'wanted.csv', {
    onBatch: async (batch) => {
      for (const e of batch) imported.push({ plate: e.plate, summary: e.rawSummary });
    },
  });

  assert.equal(imported.length, 2);
  assert.equal(imported[0].plate, 'بحه0324');
  assert.equal(imported[1].plate, 'ابج0012');
});

test('parsePastedPlatesText normalizes pasted plates', () => {
  const res = parsePastedPlatesText('ب ح هـ 324\nر ح م 3249 | بنك القاهرة');
  assert.equal(res.length, 2);
  assert.equal(res[0].plate, 'بحه0324');
  assert.equal(res[1].plate, 'رحم3249');
});
