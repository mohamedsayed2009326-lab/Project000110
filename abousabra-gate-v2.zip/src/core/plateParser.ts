import type { PlateStatus, VehicleType } from './types';

const ARABIC_INDIC_MAP: Record<string, string> = {
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
};

const SPOKEN_LETTER_MAP: Record<string, string> = {
  'الف': 'ا',
  'ألف': 'ا',
  'الالف': 'ا',
  'همزه': 'ا',
  'همزة': 'ا',
  'با': 'ب',
  'باء': 'ب',
  'به': 'ب',
  'تا': 'ت',
  'تاء': 'ت',
  'ته': 'ت',
  'ثا': 'ث',
  'ثاء': 'ث',
  'جيم': 'ج',
  'حا': 'ح',
  'حاء': 'ح',
  'خا': 'خ',
  'خاء': 'خ',
  'دال': 'د',
  'ذال': 'ذ',
  'را': 'ر',
  'راء': 'ر',
  'ره': 'ر',
  'زاي': 'ز',
  'زين': 'ز',
  'زا': 'ز',
  'سين': 'س',
  'شين': 'ش',
  'صاد': 'ص',
  'ضاد': 'ض',
  'طا': 'ط',
  'طاء': 'ط',
  'ظا': 'ظ',
  'ظاء': 'ظ',
  'عين': 'ع',
  'غين': 'غ',
  'فا': 'ف',
  'فاء': 'ف',
  'قاف': 'ق',
  'كاف': 'ك',
  'لام': 'ل',
  'ميم': 'م',
  'نون': 'ن',
  'ها': 'ه',
  'هاء': 'ه',
  'واو': 'و',
  'يا': 'ي',
  'ياء': 'ي',
};

const SPOKEN_DIGIT_MAP: Record<string, string> = {
  'صفر': '0',
  'زيرو': '0',
  'واحد': '1',
  'واحدة': '1',
  'اتنين': '2',
  'اثنين': '2',
  'تلاتة': '3',
  'تلاته': '3',
  'ثلاثة': '3',
  'ثلاثه': '3',
  'اربعة': '4',
  'أربعة': '4',
  'اربعه': '4',
  'أربعه': '4',
  'خمسة': '5',
  'خمسه': '5',
  'ستة': '6',
  'سته': '6',
  'سبعة': '7',
  'سبعه': '7',
  'تمانية': '8',
  'تمانيه': '8',
  'ثمانية': '8',
  'ثمانيه': '8',
  'تسعة': '9',
  'تسعه': '9',
};

export const VEHICLE_TYPE_ALIASES: Record<string, VehicleType> = {
  'ملاكي': 'ملاكي',
  'نقل': 'نقل',
  'هايلوكس': 'هاي لوكس',
  'هايلكس': 'هاي لوكس',
  'هاي لوكس': 'هاي لوكس',
  'هاياس': 'هاي اس',
  'هايس': 'هاي اس',
  'هاي اس': 'هاي اس',
  'هاي إس': 'هاي اس',
  'مركونة': 'مركونة',
  'مركونه': 'مركونة',
  'ونيت': 'ونيت',
  'وانيت': 'ونيت',
  'تاكسي': 'تاكسي',
  'ميكروباص': 'ميكروباص',
  'مكروباص': 'ميكروباص',
};

export const VEHICLE_TYPES: VehicleType[] = [
  'ملاكي',
  'نقل',
  'هاي لوكس',
  'هاي اس',
  'مركونة',
  'ونيت',
  'تاكسي',
  'ميكروباص',
];

export const CUSTOM_VOCABULARY: string[] = [
  'ألف', 'باء', 'جيم', 'حاء', 'دال', 'راء', 'سين', 'صاد', 'طاء',
  'عين', 'قاف', 'كاف', 'لام', 'ميم', 'نون', 'هاء', 'واو', 'ياء',
  'ملاكي', 'نقل', 'هاي لوكس', 'هاي اس', 'مركونة', 'ونيت', 'تاكسي', 'ميكروباص',
  'صفر', 'واحد', 'اتنين', 'تلاتة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'تمانية', 'تسعة',
];

export function normalizeDigits(input: string): string {
  return input.replace(/[٠-٩۰-۹]/g, (ch) => ARABIC_INDIC_MAP[ch] ?? ch);
}

export function normalizeArabicLetters(input: string): string {
  return input
    .replace(/[\u0640\u064B-\u065F\u0670\u06D6-\u06ED]/g, '') // strip tatweel & tashkeel
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه');
}

export function normalizeTokenRaw(token: string): string {
  return normalizeDigits(token)
    .replace(/[\u0640\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .trim();
}

export function normalizePlateText(raw: string): string {
  const cleaned = normalizeDigits(normalizeArabicLetters(raw))
    .replace(/[^\u0621-\u064A0-9]/g, '');
  const lettersMatch = cleaned.match(/[\u0621-\u064A]+/g)?.join('') ?? '';
  const digitsMatch = cleaned.match(/[0-9]+/g)?.join('') ?? '';
  if (!lettersMatch && !digitsMatch) return '';
  if (digitsMatch.length > 0 && digitsMatch.length < 4) {
    return lettersMatch + digitsMatch.padStart(4, '0');
  }
  return lettersMatch + digitsMatch;
}

export function splitPlateParts(plate: string): { letters: string; digits: string } {
  const norm = normalizePlateText(plate);
  const letters = (norm.match(/[\u0621-\u064A]/g) ?? []).join('');
  const digits = (norm.match(/[0-9]/g) ?? []).join('');
  return { letters, digits };
}

export function formatPlateDisplay(plate: string): string {
  const { letters, digits } = splitPlateParts(plate);
  const spacedLetters = letters.split('').join(' ');
  if (spacedLetters && digits) return `${spacedLetters} ${digits}`;
  return spacedLetters || digits || plate;
}

export function validatePlate(letters: string, digits: string): { isValid: boolean; status: PlateStatus } {
  const isValid = letters.length === 3 && digits.length === 4;
  return {
    isValid,
    status: isValid ? 'valid' : 'invalid',
  };
}

export interface ParsedPlateEvent {
  plate: string;
  letters: string;
  digits: string;
  status: PlateStatus;
  vehicleType: string;
  emittedAt: number;
}

export interface StreamParserCallbacks {
  onPlateEmitted: (event: ParsedPlateEvent) => void;
  onVehicleTypeAttached: (vehicleType: VehicleType, timestamp: number) => void;
  onStateChange?: (pending: { letters: string; digits: string }) => void;
}

const SILENCE_TIMEOUT_MS = 1500;
const VEHICLE_TYPE_WINDOW_MS = 8000;

type LexToken =
  | { kind: 'letters'; value: string }
  | { kind: 'digits'; value: string }
  | { kind: 'vehicle'; value: VehicleType; raw: string };

function tokenizeSpeechText(
  rawText: string,
  hasCurrentLetters: boolean,
  canAttachVehicleToPrevious: boolean
): LexToken[] {
  const normalized = normalizeDigits(rawText)
    .replace(/[\u0640\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
    .replace(/[.,،؛:!؟?\-_/\\()[\]{}"']/g, ' ');

  const rawWords = normalized.split(/\s+/).filter(Boolean);
  const tokens: LexToken[] = [];

  for (let i = 0; i < rawWords.length; i++) {
    const word = rawWords[i];
    const wordNorm = normalizeArabicLetters(word);
    const wordRawAlef = normalizeTokenRaw(word);

    // Check 2-word vehicle types: "هاي لوكس", "هاي اس"
    if (i + 1 < rawWords.length) {
      const nextNorm = normalizeArabicLetters(rawWords[i + 1]);
      const pair = `${wordNorm} ${nextNorm}`;
      const pairAlias = VEHICLE_TYPE_ALIASES[pair];
      if (pairAlias) {
        tokens.push({ kind: 'vehicle', value: pairAlias, raw: pair });
        i++;
        continue;
      }
    }

    // Check "نقل" special rule:
    // If "نقل" appears before any letters in current buffer AND there's no recent plate within 8s without type,
    // treat as letters ن ق ل. Otherwise treat as vehicle type!
    if (wordNorm === 'نقل') {
      const hasPendingInStream =
        hasCurrentLetters || tokens.some((t) => t.kind === 'letters' || t.kind === 'digits');
      if (hasPendingInStream || canAttachVehicleToPrevious) {
        tokens.push({ kind: 'vehicle', value: 'نقل', raw: word });
      } else {
        tokens.push({ kind: 'letters', value: 'نقل' });
      }
      continue;
    }

    // Check single-word vehicle type
    const singleVehicle = VEHICLE_TYPE_ALIASES[wordRawAlef] ?? VEHICLE_TYPE_ALIASES[wordNorm];
    if (singleVehicle) {
      tokens.push({ kind: 'vehicle', value: singleVehicle, raw: word });
      continue;
    }

    // Check spoken digit word
    const spokenDigit = SPOKEN_DIGIT_MAP[wordRawAlef] ?? SPOKEN_DIGIT_MAP[wordNorm];
    if (spokenDigit !== undefined) {
      tokens.push({ kind: 'digits', value: spokenDigit });
      continue;
    }

    // Check spoken letter name
    const spokenLetter = SPOKEN_LETTER_MAP[wordRawAlef] ?? SPOKEN_LETTER_MAP[wordNorm];
    if (spokenLetter !== undefined) {
      tokens.push({ kind: 'letters', value: spokenLetter });
      continue;
    }

    // Check mixed alphanumeric token e.g. "رحم3249" or "2020" or "ربل"
    const subParts = wordNorm.match(/[\u0621-\u064A]+|[0-9]+/g);
    if (subParts) {
      for (const part of subParts) {
        if (/^[0-9]+$/.test(part)) {
          tokens.push({ kind: 'digits', value: part });
        } else {
          // Check if part itself is a spoken letter or digit after stripping
          const sl = SPOKEN_LETTER_MAP[part];
          const sd = SPOKEN_DIGIT_MAP[part];
          if (sl) {
            tokens.push({ kind: 'letters', value: sl });
          } else if (sd) {
            tokens.push({ kind: 'digits', value: sd });
          } else {
            tokens.push({ kind: 'letters', value: part });
          }
        }
      }
    }
  }

  return tokens;
}

export class StreamPlateParser {
  private lettersBuffer = '';
  private digitsBuffer = '';
  private silenceTimer: ReturnType<typeof setTimeout> | null = null;
  private lastEmittedAt = 0;
  private lastEmittedHasType = true;
  private callbacks: StreamParserCallbacks;
  private nowFn: () => number;

  constructor(callbacks: StreamParserCallbacks, nowFn: () => number = () => Date.now()) {
    this.callbacks = callbacks;
    this.nowFn = nowFn;
  }

  private clearTimer(): void {
    if (this.silenceTimer !== null) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
  }

  private scheduleSilenceCommit(): void {
    this.clearTimer();
    if (!this.lettersBuffer && !this.digitsBuffer) return;
    this.silenceTimer = setTimeout(() => {
      this.silenceTimer = null;
      this.commitBuffer();
    }, SILENCE_TIMEOUT_MS);
  }

  private notifyState(): void {
    this.callbacks.onStateChange?.({
      letters: this.lettersBuffer,
      digits: this.digitsBuffer,
    });
  }

  private canAttachVehicle(): boolean {
    if (this.lastEmittedHasType) return false;
    return this.nowFn() - this.lastEmittedAt <= VEHICLE_TYPE_WINDOW_MS;
  }

  private commitBuffer(vehicleType = ''): boolean {
    this.clearTimer();
    if (!this.lettersBuffer && !this.digitsBuffer) {
      return false;
    }

    const letters = this.lettersBuffer;
    const rawDigits = this.digitsBuffer;
    const digits = rawDigits.length > 0 && rawDigits.length < 4
      ? rawDigits.padStart(4, '0')
      : rawDigits;
    const plate = letters + digits;
    const { status } = validatePlate(letters, digits);
    const now = this.nowFn();

    this.lettersBuffer = '';
    this.digitsBuffer = '';
    this.lastEmittedAt = now;
    this.lastEmittedHasType = Boolean(vehicleType);
    this.notifyState();

    this.callbacks.onPlateEmitted({
      plate,
      letters,
      digits,
      status,
      vehicleType,
      emittedAt: now,
    });
    return true;
  }

  public feedText(text: string): void {
    if (!text || !text.trim()) return;

    const tokens = tokenizeSpeechText(
      text,
      this.lettersBuffer.length > 0,
      this.canAttachVehicle()
    );

    for (const token of tokens) {
      if (token.kind === 'vehicle') {
        if (this.digitsBuffer.length > 0) {
          // Finish current buffered plate together with this vehicle type
          this.commitBuffer(token.value);
        } else if (this.canAttachVehicle()) {
          this.lastEmittedHasType = true;
          this.callbacks.onVehicleTypeAttached(token.value, this.nowFn());
        } else if (token.value === 'نقل' && !this.lettersBuffer && !this.digitsBuffer) {
          this.lettersBuffer += 'نقل';
          this.scheduleSilenceCommit();
          this.notifyState();
        }
        continue;
      }

      if (token.kind === 'letters') {
        // If previous plate already has digits and new letters arrive, commit old plate first
        if (this.digitsBuffer.length > 0) {
          this.commitBuffer();
        }
        this.lettersBuffer += token.value;
        this.scheduleSilenceCommit();
        this.notifyState();
        continue;
      }

      if (token.kind === 'digits') {
        for (const ch of token.value) {
          this.digitsBuffer += ch;
          if (this.digitsBuffer.length >= 4) {
            this.commitBuffer();
          }
        }
        if (this.digitsBuffer.length > 0 || this.lettersBuffer.length > 0) {
          this.scheduleSilenceCommit();
        }
        this.notifyState();
      }
    }
  }

  public flushOnTurnComplete(): void {
    this.commitBuffer();
  }

  public reset(): void {
    this.clearTimer();
    this.lettersBuffer = '';
    this.digitsBuffer = '';
    this.lastEmittedAt = 0;
    this.lastEmittedHasType = true;
    this.notifyState();
  }

  public getPending(): { letters: string; digits: string } {
    return { letters: this.lettersBuffer, digits: this.digitsBuffer };
  }
}

export function parseSinglePlateInput(rawInput: string): ParsedPlateEvent[] {
  const results: ParsedPlateEvent[] = [];
  const parser = new StreamPlateParser({
    onPlateEmitted: (ev) => {
      results.push(ev);
    },
    onVehicleTypeAttached: (vehicleType) => {
      if (results.length > 0) {
        results[results.length - 1].vehicleType = vehicleType;
      }
    },
  });
  parser.feedText(rawInput);
  parser.flushOnTurnComplete();
  return results;
}
