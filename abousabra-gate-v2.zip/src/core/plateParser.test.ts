import test from 'node:test';
import assert from 'node:assert/strict';
import {
  StreamPlateParser,
  parseSinglePlateInput,
  normalizePlateText,
  formatPlateDisplay,
  type ParsedPlateEvent,
} from './plateParser';

test('Section 4 Example 1: "ر ح م 3249" -> رحم3249', () => {
  const res = parseSinglePlateInput('ر ح م 3249');
  assert.equal(res.length, 1);
  assert.equal(res[0].plate, 'رحم3249');
  assert.equal(res[0].status, 'valid');
});

test('Section 4 Example 2: "ر ح م 324" (then silence) -> رحم0324', async () => {
  const emitted: ParsedPlateEvent[] = [];
  const parser = new StreamPlateParser({
    onPlateEmitted: (e) => emitted.push(e),
    onVehicleTypeAttached: () => {},
  });
  parser.feedText('ر ح م 324');
  assert.equal(emitted.length, 0); // waits for 1.5s silence
  await new Promise((r) => setTimeout(r, 1600));
  assert.equal(emitted.length, 1);
  assert.equal(emitted[0].plate, 'رحم0324');
  assert.equal(emitted[0].status, 'valid');
});

test('Section 4 Example 3: "را با لام ٢٠٢٠ ملاكي" -> ربل2020 + type ملاكي', () => {
  const emitted: ParsedPlateEvent[] = [];
  const parser = new StreamPlateParser({
    onPlateEmitted: (e) => emitted.push(e),
    onVehicleTypeAttached: (t) => {
      if (emitted.length > 0) emitted[emitted.length - 1].vehicleType = t;
    },
  });
  parser.feedText('را با لام ٢٠٢٠ ملاكي');
  parser.flushOnTurnComplete();
  assert.equal(emitted.length, 1);
  assert.equal(emitted[0].plate, 'ربل2020');
  assert.equal(emitted[0].vehicleType, 'ملاكي');
  assert.equal(emitted[0].status, 'valid');
});

test('Section 4 Example 4: "ربل 27" (then silence) -> ربل0027', async () => {
  const emitted: ParsedPlateEvent[] = [];
  const parser = new StreamPlateParser({
    onPlateEmitted: (e) => emitted.push(e),
    onVehicleTypeAttached: () => {},
  });
  parser.feedText('ربل 27');
  await new Promise((r) => setTimeout(r, 1600));
  assert.equal(emitted.length, 1);
  assert.equal(emitted[0].plate, 'ربل0027');
  assert.equal(emitted[0].status, 'valid');
});

test('Section 4 Example 5: "ا ب ج 1234 س ص ع 5555 نقل" -> ابج1234 and سصع5555 (type نقل)', () => {
  const emitted: ParsedPlateEvent[] = [];
  const parser = new StreamPlateParser({
    onPlateEmitted: (e) => emitted.push(e),
    onVehicleTypeAttached: (t) => {
      if (emitted.length > 0) emitted[emitted.length - 1].vehicleType = t;
    },
  });
  parser.feedText('ا ب ج 1234 س ص ع 5555 نقل');
  parser.flushOnTurnComplete();
  assert.equal(emitted.length, 2);
  assert.equal(emitted[0].plate, 'ابج1234');
  assert.equal(emitted[0].vehicleType, '');
  assert.equal(emitted[1].plate, 'سصع5555');
  assert.equal(emitted[1].vehicleType, 'نقل');
});

test('Section 4 Example 6: "ر ب ل 6 4 9 2" -> ربل6492', () => {
  const res = parseSinglePlateInput('ر ب ل 6 4 9 2');
  assert.equal(res.length, 1);
  assert.equal(res[0].plate, 'ربل6492');
  assert.equal(res[0].status, 'valid');
});

test('Streaming fragments across chunks & "نقل" as letters before plate', () => {
  const emitted: ParsedPlateEvent[] = [];
  const parser = new StreamPlateParser({
    onPlateEmitted: (e) => emitted.push(e),
    onVehicleTypeAttached: (t) => {
      if (emitted.length > 0) emitted[emitted.length - 1].vehicleType = t;
    },
  });
  parser.feedText('نقل');
  parser.feedText('خمسة');
  parser.flushOnTurnComplete();
  assert.equal(emitted.length, 1);
  assert.equal(emitted[0].plate, 'نقل0005');
  assert.equal(emitted[0].status, 'valid');
});

test('Normalization strips tatweel, alef variants, and formats spaced letters', () => {
  assert.equal(normalizePlateText('ب ح هـ ٣٢٤'), 'بحه0324');
  assert.equal(normalizePlateText('أ إ آ 27'), 'ااا0027');
  assert.equal(normalizePlateText('ر ب ى 5'), 'ربي0005');
  assert.equal(formatPlateDisplay('رحم3249'), 'ر ح م 3249');
});

test('Incomplete plate (< 3 letters) is marked invalid', () => {
  const res = parseSinglePlateInput('ر ح 1234');
  assert.equal(res.length, 1);
  assert.equal(res[0].plate, 'رح1234');
  assert.equal(res[0].status, 'invalid');
});
