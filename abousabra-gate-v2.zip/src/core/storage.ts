import type { AppSettings, GeoZone, PlateRecord, WatchlistEntry } from './types';
import type { NeighborhoodCacheEntry } from './geoZones';

const KEYS = {
  RECORDS: 'abousabra_records_v1',
  SETTINGS: 'abousabra_settings_v1',
  ZONES: 'abousabra_zones_v1',
  GEO_CACHE: 'abousabra_geocache_v1',
};

const DB_NAME = 'abousabra_gate_db';
const DB_VERSION = 1;
const STORE_WATCHLIST = 'watchlist';

export function loadRecords(): PlateRecord[] {
  try {
    const raw = localStorage.getItem(KEYS.RECORDS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveRecords(records: PlateRecord[]): void {
  try {
    localStorage.setItem(KEYS.RECORDS, JSON.stringify(records));
  } catch {
    // Ignore storage quota errors gracefully
  }
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(KEYS.SETTINGS);
    if (!raw) {
      return {
        theme: 'dark',
        mode: 'abousabra',
      };
    }
    const parsed = JSON.parse(raw);
    return {
      theme: parsed.theme === 'light' ? 'light' : 'dark',
      mode: parsed.mode === 'external' ? 'external' : 'abousabra',
      watchlistMeta: parsed.watchlistMeta,
    };
  } catch {
    return {
      theme: 'dark',
      mode: 'abousabra',
    };
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
  } catch {
    // Ignore
  }
}

export function loadZones(): GeoZone[] {
  try {
    const raw = localStorage.getItem(KEYS.ZONES);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveZones(zones: GeoZone[]): void {
  try {
    localStorage.setItem(KEYS.ZONES, JSON.stringify(zones));
  } catch {
    // Ignore
  }
}

export function loadGeoCache(): Record<string, NeighborhoodCacheEntry> {
  try {
    const raw = localStorage.getItem(KEYS.GEO_CACHE);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function saveGeoCache(cache: Record<string, NeighborhoodCacheEntry>): void {
  try {
    localStorage.setItem(KEYS.GEO_CACHE, JSON.stringify(cache));
  } catch {
    // Ignore
  }
}

function openWatchlistDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB غير متاح في هذا المتصفح'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_WATCHLIST)) {
        db.createObjectStore(STORE_WATCHLIST, { keyPath: 'plate' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('فشل فتح قاعدة البيانات'));
  });
}

export async function clearWatchlistDB(): Promise<void> {
  const db = await openWatchlistDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_WATCHLIST, 'readwrite');
    tx.objectStore(STORE_WATCHLIST).clear();
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error ?? new Error('فشل مسح ملف المطابقة'));
    };
  });
}

export async function putWatchlistBatch(entries: WatchlistEntry[]): Promise<void> {
  if (entries.length === 0) return;
  const db = await openWatchlistDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_WATCHLIST, 'readwrite');
    const store = tx.objectStore(STORE_WATCHLIST);
    for (const entry of entries) {
      store.put(entry);
    }
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error ?? new Error('فشل حفظ دفعة ملف المطابقة'));
    };
  });
}

export async function lookupWatchlistPlate(plate: string): Promise<WatchlistEntry | null> {
  if (!plate || typeof indexedDB === 'undefined') return null;
  try {
    const db = await openWatchlistDB();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_WATCHLIST, 'readonly');
      const req = tx.objectStore(STORE_WATCHLIST).get(plate);
      req.onsuccess = () => {
        db.close();
        resolve((req.result as WatchlistEntry | undefined) ?? null);
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });
  } catch {
    return null;
  }
}

export async function lookupWatchlistMany(plates: string[]): Promise<Map<string, WatchlistEntry>> {
  const result = new Map<string, WatchlistEntry>();
  if (plates.length === 0 || typeof indexedDB === 'undefined') return result;
  const unique = Array.from(new Set(plates.filter(Boolean)));
  const db = await openWatchlistDB();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_WATCHLIST, 'readonly');
    const store = tx.objectStore(STORE_WATCHLIST);
    for (const p of unique) {
      const req = store.get(p);
      req.onsuccess = () => {
        if (req.result) {
          result.set(p, req.result as WatchlistEntry);
        }
      };
    }
    tx.oncomplete = () => {
      db.close();
      resolve(result);
    };
    tx.onerror = () => {
      db.close();
      resolve(result);
    };
  });
}

export async function countWatchlistEntries(): Promise<number> {
  if (typeof indexedDB === 'undefined') return 0;
  try {
    const db = await openWatchlistDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(STORE_WATCHLIST, 'readonly');
      const req = tx.objectStore(STORE_WATCHLIST).count();
      req.onsuccess = () => {
        db.close();
        resolve(req.result ?? 0);
      };
      req.onerror = () => {
        db.close();
        resolve(0);
      };
    });
  } catch {
    return 0;
  }
}
