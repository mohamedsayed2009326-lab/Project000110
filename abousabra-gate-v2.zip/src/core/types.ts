export type PlateStatus = 'valid' | 'invalid' | 'wanted';

export type CheckMode = 'abousabra' | 'external';

export type VehicleType =
  | 'ملاكي'
  | 'نقل'
  | 'هاي لوكس'
  | 'هاي اس'
  | 'مركونة'
  | 'ونيت'
  | 'تاكسي'
  | 'ميكروباص';

export interface WatchlistEntry {
  plate: string;
  type?: string;
  bank?: string;
  chassis?: string;
  certificate?: string;
  extra?: Record<string, string>;
  rawSummary: string;
}

export interface PlateRecord {
  id: string;
  plate: string; // normalized: e.g. "رحم3249" (no spaces)
  letters: string;
  digits: string;
  vehicleType: string;
  status: PlateStatus;
  wantedData?: WatchlistEntry;
  timestamp: number;
  lat?: number;
  lng?: number;
  geoCapturedAt?: number;
  locationName?: string; // Zone name or neighborhood name
  locationSource?: 'zone' | 'osm' | 'bdc' | 'pending' | 'none';
  mode: CheckMode;
  source: 'voice' | 'manual';
  isNewMatch?: boolean;
}

export interface GeoPoint {
  lat: number;
  lng: number;
}

export interface GeoZone {
  id: string;
  name: string;
  points: GeoPoint[]; // 4 ordered vertices
  bbox: {
    minLat: number;
    maxLat: number;
    minLng: number;
    maxLng: number;
  };
  area: number;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  mode: CheckMode;
  watchlistMeta?: {
    fileName: string;
    count: number;
    updatedAt: number;
  };
}

export interface PendingColumnSelection {
  fileName: string;
  headers: string[];
  samples: string[][];
  onSelectColumn: (colIndex: number) => Promise<void>;
}
