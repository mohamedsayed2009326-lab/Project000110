import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, type LiveServerMessage } from '@google/genai';
import {
  extractErrorMessage,
  safeCloseWebSocket,
} from './src/core/wsUtils.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

function sendWsJson(ws: WebSocket, payload: Record<string, unknown>): void {
  if (ws.readyState !== WebSocket.OPEN) return;
  try {
    ws.send(JSON.stringify(payload));
  } catch {
    // Ignore transient send errors on closing socket
  }
}

function createGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    apiVersion: 'v1beta',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/api/live' });

  wss.on('error', (err) => {
    console.error('WebSocketServer error:', err);
  });

  wss.on('connection', async (clientWs: WebSocket) => {
    const ai = createGeminiClient();
    if (!ai) {
      sendWsJson(clientWs, {
        type: 'error',
        message: 'مفتاح Gemini غير متوفر على الخادم. يرجى إعداده في إعدادات البيئة.',
      });
      safeCloseWebSocket(clientWs, 1011, 'Missing server GEMINI_API_KEY', 1011);
      return;
    }

    let sessionClosed = false;
    let setupDone = false;
    let errorSent = false;
    let liveSession: Awaited<ReturnType<typeof ai.live.connect>> | null = null;
    const pendingAudioQueue: string[] = [];

    const cleanupLiveSession = () => {
      if (liveSession) {
        const s = liveSession;
        liveSession = null;
        try {
          s.close();
        } catch {
          // Ignore close errors
        }
      }
    };

    clientWs.on('error', () => {
      sessionClosed = true;
      cleanupLiveSession();
    });

    clientWs.on('message', (raw) => {
      if (sessionClosed) return;
      try {
        const payload = JSON.parse(raw.toString()) as { type?: string; data?: string };
        if (payload.type === 'audio' && typeof payload.data === 'string') {
          if (liveSession && setupDone) {
            liveSession.sendRealtimeInput({
              audio: { data: payload.data, mimeType: 'audio/pcm;rate=16000' },
            });
          } else if (pendingAudioQueue.length < 32) {
            pendingAudioQueue.push(payload.data);
          }
        }
      } catch {
        // Ignore malformed client frames or closed upstream session
      }
    });

    clientWs.on('close', () => {
      sessionClosed = true;
      cleanupLiveSession();
    });

    try {
      liveSession = await ai.live.connect({
        model: 'gemini-3.5-transcribe-live',
        config: {
          responseModalities: [Modality.TEXT],
          inputAudioTranscription: {
            languageCodes: ['ar-EG'],
          },
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            if (sessionClosed || clientWs.readyState !== WebSocket.OPEN) return;
            const content = message.serverContent;
            if (!content) return;

            if (content.interimInputTranscription?.text) {
              sendWsJson(clientWs, {
                type: 'interim',
                text: content.interimInputTranscription.text,
              });
            }
            if (content.inputTranscription?.text) {
              sendWsJson(clientWs, {
                type: 'transcript',
                text: content.inputTranscription.text,
              });
            }
            if (content.turnComplete) {
              sendWsJson(clientWs, { type: 'turnComplete' });
            }
          },
          onerror: (err: unknown) => {
            const msg = extractErrorMessage(
              err,
              'حدث خطأ في الاتصال بخدمة التفريغ الصوتي.'
            );
            if (!errorSent) {
              errorSent = true;
              sendWsJson(clientWs, { type: 'error', message: msg });
            }
          },
          onclose: (ev: { code?: number; reason?: string }) => {
            if (sessionClosed) return;
            sessionClosed = true;
            const isNormalClose = ev?.code === 1000;
            const reasonText = typeof ev?.reason === 'string' ? ev.reason.trim() : '';

            if ((!setupDone || (!isNormalClose && reasonText)) && !errorSent) {
              errorSent = true;
              sendWsJson(clientWs, {
                type: 'error',
                message: reasonText || 'تعذر بدء جلسة التفريغ الصوتي.',
              });
            }

            safeCloseWebSocket(
              clientWs,
              ev?.code,
              reasonText || (isNormalClose ? 'Live session closed' : 'Live session ended'),
              isNormalClose ? 1000 : 1011
            );
          },
        },
      });

      if (sessionClosed || clientWs.readyState !== WebSocket.OPEN) {
        cleanupLiveSession();
        return;
      }

      setupDone = true;
      sendWsJson(clientWs, { type: 'ready' });

      // Flush any audio buffered while connecting
      while (pendingAudioQueue.length > 0 && !sessionClosed && liveSession) {
        const chunk = pendingAudioQueue.shift()!;
        try {
          liveSession.sendRealtimeInput({
            audio: { data: chunk, mimeType: 'audio/pcm;rate=16000' },
          });
        } catch {
          break;
        }
      }
    } catch (err) {
      sessionClosed = true;
      cleanupLiveSession();
      const msg = extractErrorMessage(
        err,
        'تعذر الاتصال بخدمة Gemini Live على الخادم.'
      );
      if (!errorSent) {
        errorSent = true;
        sendWsJson(clientWs, { type: 'error', message: msg });
      }
      safeCloseWebSocket(clientWs, 1011, 'Gemini setup failed', 1011);
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
