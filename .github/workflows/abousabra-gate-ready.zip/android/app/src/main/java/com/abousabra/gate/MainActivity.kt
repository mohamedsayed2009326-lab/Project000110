package com.abousabra.gate

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingWebPermissionRequest: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null

    @Volatile
    private var pendingSharedFileName: String? = null

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = fileChooserCallback
            fileChooserCallback = null
            if (callback == null) return@registerForActivityResult

            if (result.resultCode == RESULT_OK) {
                val data = result.data
                val uris = mutableListOf<Uri>()
                val clip = data?.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) {
                        clip.getItemAt(i).uri?.let { uris.add(it) }
                    }
                } else {
                    data?.data?.let { uris.add(it) }
                }
                callback.onReceiveValue(if (uris.isNotEmpty()) uris.toTypedArray() else null)
            } else {
                callback.onReceiveValue(null)
            }
        }

    private val micPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val req = pendingWebPermissionRequest
            pendingWebPermissionRequest = null
            if (req != null) {
                if (granted) {
                    req.grant(req.resources)
                } else {
                    req.deny()
                }
            }
        }

    private val geoPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            val cb = pendingGeoCallback
            val origin = pendingGeoOrigin
            pendingGeoCallback = null
            pendingGeoOrigin = null
            if (cb != null && origin != null) {
                cb.invoke(origin, granted, false)
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen awake during field checks
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/shared/", SharedFilePathHandler())
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setGeolocationEnabled(true)
        }

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                if (!wantsAudio) {
                    request.deny()
                    return
                }
                val granted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (granted) {
                    runOnUiThread { request.grant(request.resources) }
                } else {
                    pendingWebPermissionRequest = request
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val fineGranted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                val coarseGranted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (fineGranted || coarseGranted) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    geoPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback

                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        arrayOf(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "application/vnd.ms-excel",
                            "text/csv",
                            "text/comma-separated-values",
                            "application/csv"
                        )
                    )
                }
                fileChooserLauncher.launch(Intent.createChooser(intent, "اختر ملف المطابقة"))
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        handleIncomingIntent(intent)

        // Secure context required for getUserMedia & Geolocation
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (handleIncomingIntent(intent)) {
            webView.post {
                webView.evaluateJavascript(
                    "window.onSharedFileAvailable && window.onSharedFileAvailable();",
                    null
                )
            }
        }
    }

    private fun handleIncomingIntent(intent: Intent?): Boolean {
        if (intent == null) return false
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_SEND -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
            }
            Intent.ACTION_VIEW -> intent.data
            else -> null
        }
        if (uri == null) return false

        return try {
            val sharedDir = File(cacheDir, "shared").apply { mkdirs() }
            val destFile = File(sharedDir, "file")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            pendingSharedFileName = resolveDisplayName(uri) ?: "watchlist.xlsx"
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return cursor.getString(idx)
                }
            }
        return uri.lastPathSegment
    }

    inner class SharedFilePathHandler : WebViewAssetLoader.PathHandler {
        override fun handle(path: String): WebResourceResponse? {
            if (path != "file") {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            val f = File(cacheDir, "shared/file")
            if (!f.exists()) return null
            val mime = if (pendingSharedFileName?.endsWith(".csv", true) == true) {
                "text/csv"
            } else {
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            }
            return WebResourceResponse(mime, null, FileInputStream(f))
        }
    }

    inner class AndroidBridge {
        private var saveTempFile: File? = null
        private var saveOut: FileOutputStream? = null
        private var saveFileName: String = "export.xlsx"
        private var saveMimeType: String =
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

        private var shareTempFile: File? = null
        private var shareOut: FileOutputStream? = null
        private var shareMimeType: String =
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

        @JavascriptInterface
        fun saveStart(fileName: String, mimeType: String) {
            saveOut?.close()
            saveFileName = fileName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .ifBlank { "abousabra_export.xlsx" }
            saveMimeType = mimeType.ifBlank {
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            }
            val dir = File(cacheDir, "downloads_tmp").apply { mkdirs() }
            val tmp = File(dir, "pending_save.xlsx")
            saveTempFile = tmp
            saveOut = FileOutputStream(tmp)
        }

        @JavascriptInterface
        fun saveChunk(base64Chunk: String) {
            val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
            saveOut?.write(bytes)
        }

        @JavascriptInterface
        fun saveEnd(): String {
            saveOut?.flush()
            saveOut?.close()
            saveOut = null
            val src = saveTempFile ?: return "ERR_NO_FILE"

            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, saveFileName)
                put(MediaStore.Downloads.MIME_TYPE, saveMimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return "ERR_MEDIASTORE"

            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { input -> input.copyTo(out) }
            }

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            src.delete()
            return "OK"
        }

        @JavascriptInterface
        fun shareStart(fileName: String, mimeType: String) {
            shareOut?.close()
            val safeName = fileName.replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
                .ifBlank { "abousabra_export.xlsx" }
            shareMimeType = mimeType.ifBlank {
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            }
            val shareDir = File(cacheDir, "share").apply { mkdirs() }
            val tmp = File(shareDir, safeName)
            shareTempFile = tmp
            shareOut = FileOutputStream(tmp)
        }

        @JavascriptInterface
        fun shareChunk(base64Chunk: String) {
            val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
            shareOut?.write(bytes)
        }

        @JavascriptInterface
        fun shareEnd(): String {
            shareOut?.flush()
            shareOut?.close()
            shareOut = null
            val file = shareTempFile ?: return "ERR_NO_FILE"

            val contentUri = FileProvider.getUriForFile(
                this@MainActivity,
                "${packageName}.fileprovider",
                file
            )

            runOnUiThread {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = shareMimeType
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(shareIntent, "مشاركة سجل بوابة ابو صبره"))
            }
            return "OK"
        }

        @JavascriptInterface
        fun hasSharedImportFile(): Boolean {
            return pendingSharedFileName != null && File(cacheDir, "shared/file").exists()
        }

        @JavascriptInterface
        fun getSharedImportFileName(): String {
            return pendingSharedFileName ?: "watchlist.xlsx"
        }

        @JavascriptInterface
        fun clearSharedImportFile() {
            pendingSharedFileName = null
            File(cacheDir, "shared/file").delete()
        }
    }
}
